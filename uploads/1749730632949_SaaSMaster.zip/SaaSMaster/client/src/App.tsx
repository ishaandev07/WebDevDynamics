import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/context/AuthContext";
import { ThemeProvider } from "@/context/ThemeContext";
import { useAuth } from "@/hooks/useAuth";
import { MainLayout } from "@/components/layout/MainLayout";
import { useState, useEffect } from "react";

// Pages
import { Landing } from "@/pages/landing/Landing";
import { Login } from "@/pages/auth/Login";
import { Signup } from "@/pages/auth/Signup";
import { ForgotPassword } from "@/pages/auth/ForgotPassword";
import { Dashboard } from "@/pages/dashboard/Dashboard";
import { CRM } from "@/pages/crm/CRM";
import { EPC } from "@/pages/epc/EPC";
import { Pricebook } from "@/pages/pricebook/Pricebook";
import { CPQ } from "@/pages/cpq/CPQ";
import { FinOps } from "@/pages/finops/FinOps";
import { Support } from "@/pages/support/Support";
import { Subscriptions } from "@/pages/subscriptions/Subscriptions";
import { Orders } from "@/pages/orders/Orders";
import { Marketplace } from "@/pages/marketplace/Marketplace";
import { Onboarding } from "@/pages/onboarding/Onboarding";
import { AdminSettings } from "@/pages/admin/AdminSettings";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return <>{children}</>;
}

function AppContent() {
  const { user } = useAuth();
  const [location, setLocation] = useLocation();
  const [activeModule, setActiveModule] = useState("dashboard");

  // Update activeModule when location changes
  useEffect(() => {
    const path = location.replace('/', '') || 'dashboard';
    setActiveModule(path);
  }, [location]);

  const handleModuleChange = (module: string) => {
    setActiveModule(module);
    setLocation(`/${module}`);
  };

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={Landing} />
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/forgot-password" component={ForgotPassword} />
      
      {/* Protected routes */}
      <Route path="/dashboard">
        <ProtectedRoute>
          <MainLayout activeModule={activeModule} onModuleChange={handleModuleChange}>
            <Dashboard />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/crm">
        <ProtectedRoute>
          <MainLayout activeModule="crm" onModuleChange={handleModuleChange}>
            <CRM />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/epc">
        <ProtectedRoute>
          <MainLayout activeModule="epc" onModuleChange={handleModuleChange}>
            <EPC />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/pricebook">
        <ProtectedRoute>
          <MainLayout activeModule="pricebook" onModuleChange={handleModuleChange}>
            <Pricebook />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/cpq">
        <ProtectedRoute>
          <MainLayout activeModule="cpq" onModuleChange={handleModuleChange}>
            <CPQ />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/finops">
        <ProtectedRoute>
          <MainLayout activeModule="finops" onModuleChange={handleModuleChange}>
            <FinOps />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/support">
        <ProtectedRoute>
          <MainLayout activeModule="support" onModuleChange={handleModuleChange}>
            <Support />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/subscriptions">
        <ProtectedRoute>
          <MainLayout activeModule="subscriptions" onModuleChange={handleModuleChange}>
            <Subscriptions />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/orders">
        <ProtectedRoute>
          <MainLayout activeModule="orders" onModuleChange={handleModuleChange}>
            <Orders />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/marketplace">
        <ProtectedRoute>
          <MainLayout activeModule="marketplace" onModuleChange={handleModuleChange}>
            <Marketplace />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/onboarding">
        <ProtectedRoute>
          <MainLayout activeModule="onboarding" onModuleChange={handleModuleChange}>
            <Onboarding />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      <Route path="/admin">
        <ProtectedRoute>
          <MainLayout activeModule="admin" onModuleChange={handleModuleChange}>
            <AdminSettings />
          </MainLayout>
        </ProtectedRoute>
      </Route>

      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ThemeProvider>
          <TooltipProvider>
            <Toaster />
            <AppContent />
          </TooltipProvider>
        </ThemeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
