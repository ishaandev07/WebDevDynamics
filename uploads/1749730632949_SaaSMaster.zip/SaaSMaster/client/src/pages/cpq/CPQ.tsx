import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  FileText, 
  Plus, 
  Search, 
  Filter, 
  DollarSign, 
  Edit, 
  Eye, 
  Send,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Download,
  Copy
} from "lucide-react";

export function CPQ() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");

  const quotes = [
    {
      id: 1,
      quoteNumber: "QT-2024-001",
      customerName: "Acme Corporation",
      contact: "Jane Smith",
      email: "jane@acmecorp.com",
      status: "sent",
      totalAmount: 45000,
      validUntil: "2024-02-15",
      createdDate: "2024-01-15",
      lastModified: "2024-01-16",
      items: 5,
      approvalStatus: "pending",
      assignedTo: "Sales Rep 1",
    },
    {
      id: 2,
      quoteNumber: "QT-2024-002",
      customerName: "Tech Startup Inc",
      contact: "Mike Davis",
      email: "mike@techstartup.io",
      status: "draft",
      totalAmount: 28500,
      validUntil: "2024-02-20",
      createdDate: "2024-01-14",
      lastModified: "2024-01-14",
      items: 3,
      approvalStatus: "approved",
      assignedTo: "Sales Rep 2",
    },
    {
      id: 3,
      quoteNumber: "QT-2024-003",
      customerName: "Enterprise Solutions",
      contact: "Sarah Johnson",
      email: "sarah@enterprise.com",
      status: "approved",
      totalAmount: 125000,
      validUntil: "2024-02-25",
      createdDate: "2024-01-13",
      lastModified: "2024-01-17",
      items: 8,
      approvalStatus: "approved",
      assignedTo: "Sales Rep 1",
    },
  ];

  const filteredQuotes = quotes.filter(quote => {
    const matchesSearch = quote.quoteNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         quote.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         quote.contact.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = selectedStatus === "all" || quote.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400">Draft</Badge>;
      case "sent":
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">Sent</Badge>;
      case "approved":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">Approved</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">Rejected</Badge>;
      case "expired":
        return <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400">Expired</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getApprovalIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-500" />;
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const totalQuoteValue = quotes.reduce((sum, quote) => sum + quote.totalAmount, 0);
  const approvedQuotes = quotes.filter(q => q.status === "approved").length;
  const pendingApprovals = quotes.filter(q => q.approvalStatus === "pending").length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold mb-2">Configure, Price, Quote (CPQ)</h1>
          <p className="text-muted-foreground">
            Quote builder, approval workflows, and quote tracking
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          New Quote
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Quotes</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{quotes.length}</div>
            <p className="text-xs text-muted-foreground">+5 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Quote Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalQuoteValue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Total pipeline</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{approvedQuotes}</div>
            <p className="text-xs text-muted-foreground">{Math.round((approvedQuotes / quotes.length) * 100)}% approval rate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approval</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingApprovals}</div>
            <p className="text-xs text-muted-foreground">Awaiting review</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="quotes" className="w-full">
        <TabsList>
          <TabsTrigger value="quotes">Quotes</TabsTrigger>
          <TabsTrigger value="approvals">Approvals</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="quotes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Quote Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-6">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Search quotes..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="sent">Sent</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </div>

              <div className="rounded-md border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-4 font-medium">Quote</th>
                      <th className="text-left p-4 font-medium">Customer</th>
                      <th className="text-left p-4 font-medium">Amount</th>
                      <th className="text-left p-4 font-medium">Status</th>
                      <th className="text-left p-4 font-medium">Approval</th>
                      <th className="text-left p-4 font-medium">Valid Until</th>
                      <th className="text-left p-4 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredQuotes.map((quote) => (
                      <tr key={quote.id} className="border-b hover:bg-muted/50">
                        <td className="p-4">
                          <div>
                            <div className="font-medium">{quote.quoteNumber}</div>
                            <div className="text-sm text-muted-foreground">
                              {quote.items} items • Created {quote.createdDate}
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <div>
                            <div className="font-medium">{quote.customerName}</div>
                            <div className="text-sm text-muted-foreground">
                              {quote.contact} • {quote.email}
                            </div>
                          </div>
                        </td>
                        <td className="p-4 font-medium">${quote.totalAmount.toLocaleString()}</td>
                        <td className="p-4">{getStatusBadge(quote.status)}</td>
                        <td className="p-4">
                          <div className="flex items-center space-x-2">
                            {getApprovalIcon(quote.approvalStatus)}
                            <span className="text-sm capitalize">{quote.approvalStatus}</span>
                          </div>
                        </td>
                        <td className="p-4 text-sm">
                          <div>{quote.validUntil}</div>
                          <div className="text-muted-foreground">
                            {new Date(quote.validUntil) < new Date() ? "Expired" : "Active"}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Send className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approvals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Approval Workflow</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {quotes.filter(q => q.approvalStatus === "pending").map((quote) => (
                  <div key={quote.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-medium">{quote.quoteNumber}</h4>
                        <p className="text-sm text-muted-foreground">
                          {quote.customerName} • ${quote.totalAmount.toLocaleString()}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                          <XCircle className="h-4 w-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Assigned to: {quote.assignedTo} • Created: {quote.createdDate}
                    </div>
                  </div>
                ))}
                
                {quotes.filter(q => q.approvalStatus === "pending").length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    No quotes pending approval
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Quote Templates</CardTitle>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Template
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-muted-foreground text-center py-8">
                Quote template management interface would be implemented here
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>CPQ Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="approval-threshold">Approval Threshold ($)</Label>
                  <Input id="approval-threshold" type="number" placeholder="10000" className="mt-2" />
                  <p className="text-sm text-muted-foreground mt-1">
                    Quotes above this amount require approval
                  </p>
                </div>
                
                <div>
                  <Label htmlFor="quote-validity">Default Quote Validity (days)</Label>
                  <Input id="quote-validity" type="number" placeholder="30" className="mt-2" />
                </div>
                
                <div>
                  <Label htmlFor="discount-limit">Maximum Discount (%)</Label>
                  <Input id="discount-limit" type="number" placeholder="25" className="mt-2" />
                </div>
                
                <Button>Save Settings</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
