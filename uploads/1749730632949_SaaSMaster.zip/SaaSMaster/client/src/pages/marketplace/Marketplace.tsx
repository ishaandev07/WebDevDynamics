import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Store, 
  Search, 
  Filter, 
  ShoppingCart, 
  Star, 
  Heart,
  Grid3X3,
  List,
  SortAsc,
  Plus,
  Package,
  DollarSign,
  Eye,
  Users,
  TrendingUp
} from "lucide-react";

export function Marketplace() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedPriceRange, setSelectedPriceRange] = useState("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [sortBy, setSortBy] = useState("popular");

  const categories = [
    { id: "all", name: "All Categories" },
    { id: "software", name: "Software" },
    { id: "hardware", name: "Hardware" },
    { id: "services", name: "Services" },
    { id: "integrations", name: "Integrations" },
    { id: "templates", name: "Templates" },
  ];

  const products = [
    {
      id: 1,
      name: "Enterprise CRM Integration",
      vendor: "TechCorp Solutions",
      category: "integrations",
      price: 299,
      pricingModel: "monthly",
      rating: 4.8,
      reviews: 156,
      image: "/api/placeholder/300/200",
      description: "Seamlessly integrate your CRM with our platform for enhanced customer management.",
      features: ["Real-time sync", "Custom fields", "Automated workflows", "24/7 support"],
      popular: true,
      sales: 1247,
      lastUpdated: "2024-01-15",
    },
    {
      id: 2,
      name: "Advanced Analytics Dashboard",
      vendor: "DataViz Pro",
      category: "software",
      price: 149,
      pricingModel: "monthly",
      rating: 4.6,
      reviews: 89,
      image: "/api/placeholder/300/200",
      description: "Comprehensive analytics and reporting tools for data-driven decisions.",
      features: ["Custom reports", "Real-time data", "Export options", "Mobile access"],
      popular: false,
      sales: 834,
      lastUpdated: "2024-01-12",
    },
    {
      id: 3,
      name: "Professional Services Package",
      vendor: "Consulting Experts",
      category: "services",
      price: 2500,
      pricingModel: "one-time",
      rating: 4.9,
      reviews: 45,
      image: "/api/placeholder/300/200",
      description: "Expert consultation and implementation services for complex projects.",
      features: ["Project management", "Custom development", "Training", "Ongoing support"],
      popular: true,
      sales: 234,
      lastUpdated: "2024-01-10",
    },
    {
      id: 4,
      name: "Marketing Automation Templates",
      vendor: "Marketing Pro",
      category: "templates",
      price: 49,
      pricingModel: "one-time",
      rating: 4.4,
      reviews: 203,
      image: "/api/placeholder/300/200",
      description: "Pre-built marketing automation workflows and email templates.",
      features: ["50+ templates", "Drag & drop editor", "A/B testing", "Analytics"],
      popular: false,
      sales: 567,
      lastUpdated: "2024-01-08",
    },
    {
      id: 5,
      name: "API Gateway Solution",
      vendor: "DevTools Inc",
      category: "software",
      price: 199,
      pricingModel: "monthly",
      rating: 4.7,
      reviews: 78,
      image: "/api/placeholder/300/200",
      description: "Secure and scalable API management platform with monitoring and analytics.",
      features: ["Rate limiting", "Authentication", "Monitoring", "Documentation"],
      popular: false,
      sales: 345,
      lastUpdated: "2024-01-05",
    },
    {
      id: 6,
      name: "Hardware Monitoring Kit",
      vendor: "IoT Solutions",
      category: "hardware",
      price: 899,
      pricingModel: "one-time",
      rating: 4.5,
      reviews: 34,
      image: "/api/placeholder/300/200",
      description: "Complete hardware monitoring solution with sensors and analytics.",
      features: ["Temperature sensors", "Real-time alerts", "Cloud dashboard", "Mobile app"],
      popular: false,
      sales: 123,
      lastUpdated: "2024-01-03",
    },
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.vendor.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
    
    let matchesPrice = true;
    if (selectedPriceRange !== "all") {
      const price = product.price;
      switch (selectedPriceRange) {
        case "under-100":
          matchesPrice = price < 100;
          break;
        case "100-500":
          matchesPrice = price >= 100 && price <= 500;
          break;
        case "500-1000":
          matchesPrice = price > 500 && price <= 1000;
          break;
        case "over-1000":
          matchesPrice = price > 1000;
          break;
      }
    }
    
    return matchesSearch && matchesCategory && matchesPrice;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "popular":
        return b.sales - a.sales;
      case "rating":
        return b.rating - a.rating;
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "newest":
        return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
      default:
        return 0;
    }
  });

  const totalProducts = products.length;
  const totalVendors = [...new Set(products.map(p => p.vendor))].length;
  const averageRating = (products.reduce((sum, p) => sum + p.rating, 0) / products.length).toFixed(1);
  const totalSales = products.reduce((sum, p) => sum + p.sales, 0);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold mb-2">Marketplace</h1>
          <p className="text-muted-foreground">
            Product catalog with filtering, pricing display, and add-to-cart integration
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Heart className="h-4 w-4 mr-2" />
            Wishlist (3)
          </Button>
          <Button>
            <ShoppingCart className="h-4 w-4 mr-2" />
            Cart (2)
          </Button>
        </div>
      </div>

      {/* Marketplace Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalProducts}</div>
            <p className="text-xs text-muted-foreground">+5 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Vendors</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalVendors}</div>
            <p className="text-xs text-muted-foreground">Verified partners</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            <Star className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageRating}</div>
            <p className="text-xs text-muted-foreground">Out of 5 stars</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalSales.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="browse" className="w-full">
        <TabsList>
          <TabsTrigger value="browse">Browse Products</TabsTrigger>
          <TabsTrigger value="vendors">Vendors</TabsTrigger>
          <TabsTrigger value="featured">Featured</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="space-y-4">
          {/* Filters and Search */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Search products, vendors, or features..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={selectedPriceRange} onValueChange={setSelectedPriceRange}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Price Range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Prices</SelectItem>
                      <SelectItem value="under-100">Under $100</SelectItem>
                      <SelectItem value="100-500">$100 - $500</SelectItem>
                      <SelectItem value="500-1000">$500 - $1000</SelectItem>
                      <SelectItem value="over-1000">Over $1000</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="popular">Most Popular</SelectItem>
                      <SelectItem value="rating">Highest Rated</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="newest">Newest</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="flex border rounded-md">
                    <Button
                      variant={viewMode === "grid" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("grid")}
                    >
                      <Grid3X3 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("list")}
                    >
                      <List className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Products Grid/List */}
          <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
            {sortedProducts.map((product) => (
              <Card key={product.id} className={`group hover:shadow-lg transition-shadow ${viewMode === "list" ? "flex" : ""}`}>
                {viewMode === "grid" ? (
                  <>
                    <div className="relative">
                      <div className="aspect-video bg-muted rounded-t-lg flex items-center justify-center">
                        <Package className="h-12 w-12 text-muted-foreground" />
                      </div>
                      {product.popular && (
                        <Badge className="absolute top-2 left-2 bg-orange-500">
                          Popular
                        </Badge>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <div>
                          <h3 className="font-semibold line-clamp-1">{product.name}</h3>
                          <p className="text-sm text-muted-foreground">{product.vendor}</p>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm ml-1">{product.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">({product.reviews})</span>
                          <Badge variant="outline" className="text-xs capitalize">
                            {product.category}
                          </Badge>
                        </div>

                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {product.description}
                        </p>

                        <div className="flex items-center justify-between pt-2">
                          <div className="text-lg font-bold">
                            ${product.price}
                            <span className="text-sm font-normal text-muted-foreground">
                              /{product.pricingModel === "monthly" ? "mo" : "once"}
                            </span>
                          </div>
                          <Button size="sm">
                            <ShoppingCart className="h-4 w-4 mr-2" />
                            Add to Cart
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </>
                ) : (
                  <div className="flex w-full">
                    <div className="w-48 h-32 bg-muted flex items-center justify-center rounded-l-lg">
                      <Package className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <CardContent className="flex-1 p-4">
                      <div className="flex justify-between h-full">
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h3 className="font-semibold">{product.name}</h3>
                              <p className="text-sm text-muted-foreground">{product.vendor}</p>
                            </div>
                            {product.popular && (
                              <Badge className="bg-orange-500">Popular</Badge>
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-4 mb-2">
                            <div className="flex items-center">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm ml-1">{product.rating} ({product.reviews})</span>
                            </div>
                            <Badge variant="outline" className="text-xs capitalize">
                              {product.category}
                            </Badge>
                          </div>

                          <p className="text-sm text-muted-foreground mb-2">
                            {product.description}
                          </p>

                          <div className="flex flex-wrap gap-1">
                            {product.features.slice(0, 3).map((feature, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                            {product.features.length > 3 && (
                              <Badge variant="secondary" className="text-xs">
                                +{product.features.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex flex-col justify-between ml-4">
                          <div className="text-right">
                            <div className="text-lg font-bold">
                              ${product.price}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              /{product.pricingModel === "monthly" ? "month" : "one-time"}
                            </div>
                          </div>
                          
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm">
                              <ShoppingCart className="h-4 w-4 mr-2" />
                              Add to Cart
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </div>
                )}
              </Card>
            ))}
          </div>

          {sortedProducts.length === 0 && (
            <Card>
              <CardContent className="py-8 text-center">
                <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No products found matching your criteria.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="vendors" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Vendor Directory</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-muted-foreground text-center py-8">
                Vendor management interface would be implemented here
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="featured" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Featured Products</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.filter(p => p.popular).map((product) => (
                  <Card key={product.id} className="group hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <div className="aspect-video bg-muted rounded-t-lg flex items-center justify-center">
                        <Package className="h-12 w-12 text-muted-foreground" />
                      </div>
                      <Badge className="absolute top-2 left-2 bg-orange-500">
                        Featured
                      </Badge>
                    </div>
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <div>
                          <h3 className="font-semibold">{product.name}</h3>
                          <p className="text-sm text-muted-foreground">{product.vendor}</p>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm ml-1">{product.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">({product.reviews})</span>
                        </div>

                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {product.description}
                        </p>

                        <div className="flex items-center justify-between pt-2">
                          <div className="text-lg font-bold">
                            ${product.price}
                            <span className="text-sm font-normal text-muted-foreground">
                              /{product.pricingModel === "monthly" ? "mo" : "once"}
                            </span>
                          </div>
                          <Button size="sm">
                            <ShoppingCart className="h-4 w-4 mr-2" />
                            Add to Cart
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Sales Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-muted-foreground text-center py-8">
                  Sales analytics chart would be implemented here
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Popular Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-muted-foreground text-center py-8">
                  Category performance analytics would be implemented here
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
