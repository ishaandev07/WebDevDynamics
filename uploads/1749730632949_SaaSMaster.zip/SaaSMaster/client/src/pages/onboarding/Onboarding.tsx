import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  UserPlus, 
  Users, 
  Building, 
  FileText, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  X,
  Eye,
  Edit,
  Send,
  Download,
  ArrowRight,
  ArrowLeft,
  Star,
  Shield,
  Briefcase
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export function Onboarding() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const [currentStep, setCurrentStep] = useState(1);

  const onboardingRequests = [
    {
      id: 1,
      applicantName: "TechStart Solutions",
      applicantEmail: "admin@techstart.com",
      type: "partner",
      status: "pending_review",
      submittedDate: "2024-01-15",
      completionPercent: 85,
      requiredDocuments: ["Business License", "Tax Certificate", "References"],
      submittedDocuments: ["Business License", "Tax Certificate"],
      reviewerNotes: "Pending reference verification",
      estimatedCompletion: "2024-01-25",
    },
    {
      id: 2,
      applicantName: "Global Enterprise Corp",
      applicantEmail: "procurement@globalent.com",
      type: "customer",
      status: "approved",
      submittedDate: "2024-01-10",
      completionPercent: 100,
      requiredDocuments: ["Company Info", "Purchase Agreement"],
      submittedDocuments: ["Company Info", "Purchase Agreement"],
      reviewerNotes: "All requirements met. Account activated.",
      estimatedCompletion: "2024-01-20",
    },
    {
      id: 3,
      applicantName: "Retail Solutions Inc",
      applicantEmail: "contact@retailsol.com",
      type: "customer",
      status: "incomplete",
      submittedDate: "2024-01-12",
      completionPercent: 45,
      requiredDocuments: ["Company Info", "Credit Check", "Purchase Agreement"],
      submittedDocuments: ["Company Info"],
      reviewerNotes: "Awaiting credit check and purchase agreement",
      estimatedCompletion: "2024-01-30",
    },
    {
      id: 4,
      applicantName: "Innovation Partners LLC",
      applicantEmail: "partnerships@innovation.com",
      type: "partner",
      status: "rejected",
      submittedDate: "2024-01-08",
      completionPercent: 75,
      requiredDocuments: ["Business License", "Insurance", "Portfolio"],
      submittedDocuments: ["Business License", "Insurance"],
      reviewerNotes: "Portfolio does not meet minimum requirements",
      estimatedCompletion: null,
    },
  ];

  const onboardingSteps = {
    customer: [
      { id: 1, title: "Company Information", description: "Basic company details and contact information" },
      { id: 2, title: "Business Verification", description: "Upload required business documents" },
      { id: 3, title: "Service Selection", description: "Choose your service plan and preferences" },
      { id: 4, title: "Payment Setup", description: "Configure billing and payment methods" },
      { id: 5, title: "Account Activation", description: "Final review and account setup" },
    ],
    partner: [
      { id: 1, title: "Partner Application", description: "Submit partner application with company details" },
      { id: 2, title: "Qualifications Review", description: "Technical and business qualification assessment" },
      { id: 3, title: "Documentation", description: "Upload certifications and required documents" },
      { id: 4, title: "Agreement Signing", description: "Review and sign partner agreement" },
      { id: 5, title: "Training & Onboarding", description: "Complete partner training program" },
      { id: 6, title: "Account Activation", description: "Partner portal access and commission setup" },
    ],
  };

  const filteredRequests = onboardingRequests.filter(request => {
    const matchesSearch = request.applicantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         request.applicantEmail.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = selectedStatus === "all" || request.status === selectedStatus;
    const matchesType = selectedType === "all" || request.type === selectedType;
    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending_review":
        return <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400">Pending Review</Badge>;
      case "approved":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">Approved</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">Rejected</Badge>;
      case "incomplete":
        return <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400">Incomplete</Badge>;
      case "in_progress":
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">In Progress</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "rejected":
        return <X className="h-4 w-4 text-red-500" />;
      case "pending_review":
      case "in_progress":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case "incomplete":
        return <AlertTriangle className="h-4 w-4 text-orange-500" />;
      default:
        return null;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "customer":
        return <Building className="h-4 w-4 text-blue-500" />;
      case "partner":
        return <Briefcase className="h-4 w-4 text-purple-500" />;
      default:
        return <Users className="h-4 w-4 text-gray-500" />;
    }
  };

  const totalRequests = onboardingRequests.length;
  const pendingRequests = onboardingRequests.filter(r => r.status === "pending_review").length;
  const approvedRequests = onboardingRequests.filter(r => r.status === "approved").length;
  const avgCompletionTime = "5.2 days";

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold mb-2">Partner & Customer Onboarding</h1>
          <p className="text-muted-foreground">
            Registration wizard with validation and approval workflows
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
          <Button>
            <UserPlus className="h-4 w-4 mr-2" />
            New Application
          </Button>
        </div>
      </div>

      {/* Onboarding Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
            <UserPlus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalRequests}</div>
            <p className="text-xs text-muted-foreground">+3 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingRequests}</div>
            <p className="text-xs text-muted-foreground">Awaiting approval</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{approvedRequests}</div>
            <p className="text-xs text-muted-foreground">{Math.round((approvedRequests / totalRequests) * 100)}% approval rate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Completion Time</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgCompletionTime}</div>
            <p className="text-xs text-muted-foreground">From submission to approval</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="applications" className="w-full">
        <TabsList>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="wizard">Onboarding Wizard</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="applications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Onboarding Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-6">
                <div className="flex-1">
                  <div className="relative">
                    <UserPlus className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Search applications..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending_review">Pending Review</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="incomplete">Incomplete</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="customer">Customer</SelectItem>
                    <SelectItem value="partner">Partner</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4">
                {filteredRequests.map((request) => (
                  <Card key={request.id} className="border">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            {getTypeIcon(request.type)}
                            <div>
                              <h3 className="font-semibold">{request.applicantName}</h3>
                              <p className="text-sm text-muted-foreground">{request.applicantEmail}</p>
                            </div>
                            <Badge variant="outline" className="capitalize">
                              {request.type}
                            </Badge>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                            <div>
                              <div className="text-sm font-medium mb-1">Status</div>
                              <div className="flex items-center space-x-2">
                                {getStatusIcon(request.status)}
                                {getStatusBadge(request.status)}
                              </div>
                            </div>
                            <div>
                              <div className="text-sm font-medium mb-1">Progress</div>
                              <div className="space-y-1">
                                <Progress value={request.completionPercent} className="h-2" />
                                <div className="text-xs text-muted-foreground">
                                  {request.completionPercent}% complete
                                </div>
                              </div>
                            </div>
                            <div>
                              <div className="text-sm font-medium mb-1">Submitted</div>
                              <div className="text-sm text-muted-foreground">{request.submittedDate}</div>
                            </div>
                            <div>
                              <div className="text-sm font-medium mb-1">Est. Completion</div>
                              <div className="text-sm text-muted-foreground">
                                {request.estimatedCompletion || "TBD"}
                              </div>
                            </div>
                          </div>

                          <div className="mb-4">
                            <div className="text-sm font-medium mb-2">Documents</div>
                            <div className="flex flex-wrap gap-2">
                              {request.requiredDocuments.map((doc) => (
                                <Badge 
                                  key={doc}
                                  variant={request.submittedDocuments.includes(doc) ? "default" : "secondary"}
                                  className={request.submittedDocuments.includes(doc) ? "bg-green-100 text-green-800" : ""}
                                >
                                  {request.submittedDocuments.includes(doc) && (
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                  )}
                                  {doc}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          {request.reviewerNotes && (
                            <div>
                              <div className="text-sm font-medium mb-1">Notes</div>
                              <p className="text-sm text-muted-foreground">{request.reviewerNotes}</p>
                            </div>
                          )}
                        </div>

                        <div className="flex space-x-2 ml-4">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          {request.status === "pending_review" && (
                            <>
                              <Button size="sm" className="bg-green-600 hover:bg-green-700">
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Approve
                              </Button>
                              <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                                <X className="h-4 w-4 mr-2" />
                                Reject
                              </Button>
                            </>
                          )}
                          {request.status === "incomplete" && (
                            <Button size="sm" variant="outline">
                              <Send className="h-4 w-4 mr-2" />
                              Send Reminder
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="wizard" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Onboarding Wizard Preview</CardTitle>
              <div className="flex space-x-4">
                <Button 
                  variant={selectedType === "customer" ? "default" : "outline"}
                  onClick={() => setSelectedType("customer")}
                >
                  <Building className="h-4 w-4 mr-2" />
                  Customer Onboarding
                </Button>
                <Button 
                  variant={selectedType === "partner" ? "default" : "outline"}
                  onClick={() => setSelectedType("partner")}
                >
                  <Briefcase className="h-4 w-4 mr-2" />
                  Partner Onboarding
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {selectedType !== "all" && (
                <div className="space-y-6">
                  {/* Progress Indicator */}
                  <div className="flex items-center justify-between">
                    {onboardingSteps[selectedType as keyof typeof onboardingSteps].map((step, index) => (
                      <div key={step.id} className="flex items-center">
                        <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 text-sm font-medium ${
                          currentStep >= step.id 
                            ? "bg-primary text-primary-foreground border-primary" 
                            : "border-gray-300 text-gray-500"
                        }`}>
                          {currentStep > step.id ? (
                            <CheckCircle className="h-4 w-4" />
                          ) : (
                            step.id
                          )}
                        </div>
                        {index < onboardingSteps[selectedType as keyof typeof onboardingSteps].length - 1 && (
                          <div className={`w-12 h-0.5 mx-2 ${
                            currentStep > step.id ? "bg-primary" : "bg-gray-300"
                          }`} />
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Current Step Content */}
                  <Card>
                    <CardHeader>
                      <CardTitle>
                        Step {currentStep}: {onboardingSteps[selectedType as keyof typeof onboardingSteps].find(s => s.id === currentStep)?.title}
                      </CardTitle>
                      <p className="text-muted-foreground">
                        {onboardingSteps[selectedType as keyof typeof onboardingSteps].find(s => s.id === currentStep)?.description}
                      </p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Step-specific form fields would go here */}
                      {currentStep === 1 && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="companyName">Company Name</Label>
                            <Input id="companyName" placeholder="Enter company name" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="industry">Industry</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select industry" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="technology">Technology</SelectItem>
                                <SelectItem value="healthcare">Healthcare</SelectItem>
                                <SelectItem value="finance">Finance</SelectItem>
                                <SelectItem value="retail">Retail</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="contactName">Primary Contact</Label>
                            <Input id="contactName" placeholder="Contact person name" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="contactEmail">Email</Label>
                            <Input id="contactEmail" type="email" placeholder="contact@company.com" />
                          </div>
                        </div>
                      )}

                      {currentStep === 2 && (
                        <div className="space-y-4">
                          <div className="text-sm text-muted-foreground">
                            Please upload the required documents to verify your business.
                          </div>
                          <div className="space-y-3">
                            {["Business License", "Tax Certificate", "Insurance Certificate"].map((doc) => (
                              <div key={doc} className="flex items-center justify-between p-3 border rounded-lg">
                                <div className="flex items-center space-x-3">
                                  <FileText className="h-5 w-5 text-muted-foreground" />
                                  <span>{doc}</span>
                                </div>
                                <Button variant="outline" size="sm">
                                  Upload
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Navigation */}
                      <div className="flex justify-between pt-4">
                        <Button 
                          variant="outline" 
                          onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
                          disabled={currentStep === 1}
                        >
                          <ArrowLeft className="h-4 w-4 mr-2" />
                          Previous
                        </Button>
                        <Button 
                          onClick={() => setCurrentStep(Math.min(onboardingSteps[selectedType as keyof typeof onboardingSteps].length, currentStep + 1))}
                          disabled={currentStep === onboardingSteps[selectedType as keyof typeof onboardingSteps].length}
                        >
                          Next
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Onboarding Templates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-muted-foreground text-center py-8">
                Template management interface would be implemented here
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Onboarding Funnel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-muted-foreground text-center py-8">
                  Funnel analytics chart would be implemented here
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Completion Times</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-muted-foreground text-center py-8">
                  Completion time analytics would be implemented here
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
