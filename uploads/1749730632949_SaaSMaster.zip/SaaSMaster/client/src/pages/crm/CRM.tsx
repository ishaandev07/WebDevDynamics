import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, Plus, Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";

export function CRM() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold mb-2">Customer Relationship Management</h1>
          <p className="text-muted-foreground">
            Manage leads, customers, and sales opportunities
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          New Lead
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Leads</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,247</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Qualified</CardTitle>
            <Badge variant="outline">432</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">34.6%</div>
            <p className="text-xs text-muted-foreground">Conversion rate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Month</CardTitle>
            <Badge variant="secondary">New</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">89</div>
            <p className="text-xs text-muted-foreground">+23% increase</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pipeline Value</CardTitle>
            <Badge className="bg-green-100 text-green-800">$2.4M</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$847K</div>
            <p className="text-xs text-muted-foreground">Weighted forecast</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle>Lead Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search leads..."
                  className="pl-10"
                />
              </div>
            </div>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
          </div>

          {/* Leads Table */}
          <div className="rounded-md border">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-4 font-medium">Lead</th>
                  <th className="text-left p-4 font-medium">Company</th>
                  <th className="text-left p-4 font-medium">Source</th>
                  <th className="text-left p-4 font-medium">Status</th>
                  <th className="text-left p-4 font-medium">Value</th>
                  <th className="text-left p-4 font-medium">Last Contact</th>
                  <th className="text-left p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b hover:bg-muted/50">
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="bg-blue-500 rounded-full w-10 h-10 flex items-center justify-center">
                        <span className="text-white font-semibold">JS</span>
                      </div>
                      <div>
                        <div className="font-medium">Jane Smith</div>
                        <div className="text-sm text-muted-foreground">jane@acmecorp.com</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">Acme Corporation</td>
                  <td className="p-4">
                    <Badge variant="outline">Website</Badge>
                  </td>
                  <td className="p-4">
                    <Badge className="bg-green-100 text-green-800">Qualified</Badge>
                  </td>
                  <td className="p-4 font-medium">$45,000</td>
                  <td className="p-4 text-sm text-muted-foreground">2 hours ago</td>
                  <td className="p-4">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">View</Button>
                      <Button variant="ghost" size="sm">Edit</Button>
                    </div>
                  </td>
                </tr>
                
                <tr className="border-b hover:bg-muted/50">
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="bg-green-500 rounded-full w-10 h-10 flex items-center justify-center">
                        <span className="text-white font-semibold">MD</span>
                      </div>
                      <div>
                        <div className="font-medium">Mike Davis</div>
                        <div className="text-sm text-muted-foreground">mike@techstartup.io</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">Tech Startup Inc</td>
                  <td className="p-4">
                    <Badge variant="outline" className="bg-green-100 text-green-800">Referral</Badge>
                  </td>
                  <td className="p-4">
                    <Badge className="bg-yellow-100 text-yellow-800">Contacted</Badge>
                  </td>
                  <td className="p-4 font-medium">$28,500</td>
                  <td className="p-4 text-sm text-muted-foreground">1 day ago</td>
                  <td className="p-4">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">View</Button>
                      <Button variant="ghost" size="sm">Edit</Button>
                    </div>
                  </td>
                </tr>

                <tr className="border-b hover:bg-muted/50">
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="bg-purple-500 rounded-full w-10 h-10 flex items-center justify-center">
                        <span className="text-white font-semibold">SJ</span>
                      </div>
                      <div>
                        <div className="font-medium">Sarah Johnson</div>
                        <div className="text-sm text-muted-foreground">sarah@enterprise.com</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">Enterprise Solutions</td>
                  <td className="p-4">
                    <Badge variant="outline" className="bg-blue-100 text-blue-800">LinkedIn</Badge>
                  </td>
                  <td className="p-4">
                    <Badge className="bg-green-100 text-green-800">Proposal Sent</Badge>
                  </td>
                  <td className="p-4 font-medium">$125,000</td>
                  <td className="p-4 text-sm text-muted-foreground">3 hours ago</td>
                  <td className="p-4">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">View</Button>
                      <Button variant="ghost" size="sm">Edit</Button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
