import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { 
  Tag, 
  Plus, 
  Search, 
  Filter, 
  DollarSign, 
  Edit, 
  Trash2, 
  Users,
  Calendar,
  Percent
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export function Pricebook() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedType, setSelectedType] = useState("all");

  const pricebooks = [
    {
      id: 1,
      name: "Standard Pricing",
      description: "Default pricing for all customers",
      type: "standard",
      status: "active",
      customerCount: 1247,
      productCount: 89,
      discountPercent: 0,
      validFrom: "2024-01-01",
      validTo: null,
      lastModified: "2024-01-15",
    },
    {
      id: 2,
      name: "Enterprise Customer Pricing",
      description: "Special pricing for enterprise accounts",
      type: "custom",
      status: "active",
      customerCount: 23,
      productCount: 89,
      discountPercent: 15,
      validFrom: "2024-01-01",
      validTo: "2024-12-31",
      lastModified: "2024-01-14",
    },
    {
      id: 3,
      name: "Partner Reseller Pricing",
      description: "Wholesale pricing for certified partners",
      type: "partner",
      status: "active",
      customerCount: 45,
      productCount: 67,
      discountPercent: 25,
      validFrom: "2024-01-01",
      validTo: "2024-12-31",
      lastModified: "2024-01-13",
    },
  ];

  const priceEntries = [
    {
      id: 1,
      productSku: "SW-ENT-001",
      productName: "Enterprise Software License",
      listPrice: 999.99,
      pricebookPrice: 849.99,
      discount: 15,
      pricebook: "Enterprise Customer Pricing",
      currency: "USD",
      lastUpdated: "2024-01-15",
    },
    {
      id: 2,
      productSku: "HW-SRV-001",
      productName: "Server Hardware Package",
      listPrice: 4999.99,
      pricebookPrice: 3749.99,
      discount: 25,
      pricebook: "Partner Reseller Pricing",
      currency: "USD",
      lastUpdated: "2024-01-14",
    },
  ];

  const filteredPricebooks = pricebooks.filter(pricebook => {
    const matchesSearch = pricebook.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === "all" || pricebook.type === selectedType;
    return matchesSearch && matchesType;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">Active</Badge>;
      case "inactive":
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">Inactive</Badge>;
      case "draft":
        return <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400">Draft</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getTypeBadge = (type: string) => {
    const colors = {
      standard: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
      custom: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
      partner: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
    };

    return (
      <Badge className={colors[type as keyof typeof colors] || colors.standard}>
        {type}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold mb-2">Pricebook Management</h1>
          <p className="text-muted-foreground">
            Create, assign, and manage pricebooks per customer or product group
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Pricebook
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Pricebook</DialogTitle>
              <DialogDescription>
                Define a new pricebook with custom pricing rules
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Pricebook Name</Label>
                  <Input id="name" placeholder="e.g., VIP Customer Pricing" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="type">Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                      <SelectItem value="partner">Partner</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" placeholder="Pricebook description" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="validFrom">Valid From</Label>
                  <Input id="validFrom" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="validTo">Valid To</Label>
                  <Input id="validTo" type="date" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="discount">Global Discount (%)</Label>
                <Input id="discount" type="number" placeholder="0" min="0" max="100" />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="active" />
                <Label htmlFor="active">Active</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsCreateDialogOpen(false)}>
                Create Pricebook
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pricebooks</CardTitle>
            <Tag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">47</div>
            <p className="text-xs text-muted-foreground">+3 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,315</div>
            <p className="text-xs text-muted-foreground">Across all pricebooks</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Discount</CardTitle>
            <Percent className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12.5%</div>
            <p className="text-xs text-muted-foreground">Weighted average</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Revenue Impact</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$2.4M</div>
            <p className="text-xs text-muted-foreground">Monthly pricing value</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="pricebooks" className="w-full">
        <TabsList>
          <TabsTrigger value="pricebooks">Pricebooks</TabsTrigger>
          <TabsTrigger value="entries">Price Entries</TabsTrigger>
          <TabsTrigger value="assignments">Customer Assignments</TabsTrigger>
        </TabsList>

        <TabsContent value="pricebooks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pricebook Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-6">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Search pricebooks..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                    <SelectItem value="partner">Partner</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </div>

              <div className="rounded-md border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-4 font-medium">Pricebook</th>
                      <th className="text-left p-4 font-medium">Type</th>
                      <th className="text-left p-4 font-medium">Status</th>
                      <th className="text-left p-4 font-medium">Customers</th>
                      <th className="text-left p-4 font-medium">Products</th>
                      <th className="text-left p-4 font-medium">Discount</th>
                      <th className="text-left p-4 font-medium">Valid Period</th>
                      <th className="text-left p-4 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPricebooks.map((pricebook) => (
                      <tr key={pricebook.id} className="border-b hover:bg-muted/50">
                        <td className="p-4">
                          <div>
                            <div className="font-medium">{pricebook.name}</div>
                            <div className="text-sm text-muted-foreground">{pricebook.description}</div>
                          </div>
                        </td>
                        <td className="p-4">{getTypeBadge(pricebook.type)}</td>
                        <td className="p-4">{getStatusBadge(pricebook.status)}</td>
                        <td className="p-4 font-medium">{pricebook.customerCount.toLocaleString()}</td>
                        <td className="p-4">{pricebook.productCount}</td>
                        <td className="p-4">
                          {pricebook.discountPercent > 0 ? (
                            <Badge className="bg-orange-100 text-orange-800">
                              -{pricebook.discountPercent}%
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">No discount</span>
                          )}
                        </td>
                        <td className="p-4 text-sm">
                          <div>{pricebook.validFrom}</div>
                          {pricebook.validTo && (
                            <div className="text-muted-foreground">to {pricebook.validTo}</div>
                          )}
                        </td>
                        <td className="p-4">
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-destructive">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="entries" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Price Entries</CardTitle>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Price Entry
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-4 font-medium">Product</th>
                      <th className="text-left p-4 font-medium">SKU</th>
                      <th className="text-left p-4 font-medium">List Price</th>
                      <th className="text-left p-4 font-medium">Pricebook Price</th>
                      <th className="text-left p-4 font-medium">Discount</th>
                      <th className="text-left p-4 font-medium">Pricebook</th>
                      <th className="text-left p-4 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {priceEntries.map((entry) => (
                      <tr key={entry.id} className="border-b hover:bg-muted/50">
                        <td className="p-4">
                          <div className="font-medium">{entry.productName}</div>
                        </td>
                        <td className="p-4 font-mono text-sm">{entry.productSku}</td>
                        <td className="p-4 font-medium">${entry.listPrice.toLocaleString()}</td>
                        <td className="p-4 font-medium text-green-600">${entry.pricebookPrice.toLocaleString()}</td>
                        <td className="p-4">
                          <Badge className="bg-orange-100 text-orange-800">
                            -{entry.discount}%
                          </Badge>
                        </td>
                        <td className="p-4 text-sm">{entry.pricebook}</td>
                        <td className="p-4">
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-destructive">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assignments" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Customer Assignments</CardTitle>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Assign Customers
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-muted-foreground text-center py-8">
                Customer assignment interface would be implemented here
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
