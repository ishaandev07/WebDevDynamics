import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  DollarSign, 
  FileText, 
  LifeBuoy, 
  ArrowUp, 
  ArrowDown,
  Minus,
  Eye,
  Edit
} from "lucide-react";
import { RevenueChart } from "@/components/charts/RevenueChart";
import { LeadSourceChart } from "@/components/charts/LeadSourceChart";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Lead } from "@shared/schema";

interface DashboardMetrics {
  totalLeads: number;
  revenue: number;
  activeQuotes: number;
  openTickets: number;
}

export function Dashboard() {
  const { user } = useAuth();

  const { data: metrics } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: leads = [] } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "qualified":
      case "won":
        return <Badge className="status-active">Qualified</Badge>;
      case "contacted":
      case "proposal":
        return <Badge className="status-pending">Contacted</Badge>;
      case "new":
      case "lost":
        return <Badge className="status-inactive">New</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getSourceBadge = (source: string) => {
    const colors = {
      website: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
      referral: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
      linkedin: "bg-blue-600 text-white",
      email: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
      other: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400",
    };

    return (
      <Badge className={colors[source as keyof typeof colors] || colors.other}>
        {source}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back, {user?.firstName}! Here's what's happening with your business today.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="dashboard-card stat-card">
          <CardContent className="p-6">
            <div className="stat-icon bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
              <Users className="h-6 w-6" />
            </div>
            <div className="stat-number">{metrics?.totalLeads?.toLocaleString() || 0}</div>
            <div className="text-muted-foreground mb-2">Total Leads</div>
            <div className="flex items-center text-sm text-green-600">
              <ArrowUp className="h-4 w-4 mr-1" />
              +12% this month
            </div>
          </CardContent>
        </Card>

        <Card className="dashboard-card stat-card">
          <CardContent className="p-6">
            <div className="stat-icon bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
              <DollarSign className="h-6 w-6" />
            </div>
            <div className="stat-number">${metrics?.revenue?.toLocaleString() || 0}</div>
            <div className="text-muted-foreground mb-2">Monthly Revenue</div>
            <div className="flex items-center text-sm text-green-600">
              <ArrowUp className="h-4 w-4 mr-1" />
              +8% this month
            </div>
          </CardContent>
        </Card>

        <Card className="dashboard-card stat-card">
          <CardContent className="p-6">
            <div className="stat-icon bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400">
              <FileText className="h-6 w-6" />
            </div>
            <div className="stat-number">{metrics?.activeQuotes || 0}</div>
            <div className="text-muted-foreground mb-2">Active Quotes</div>
            <div className="flex items-center text-sm text-muted-foreground">
              <Minus className="h-4 w-4 mr-1" />
              No change
            </div>
          </CardContent>
        </Card>

        <Card className="dashboard-card stat-card">
          <CardContent className="p-6">
            <div className="stat-icon bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400">
              <LifeBuoy className="h-6 w-6" />
            </div>
            <div className="stat-number">{metrics?.openTickets || 0}</div>
            <div className="text-muted-foreground mb-2">Open Tickets</div>
            <div className="flex items-center text-sm text-red-600">
              <ArrowUp className="h-4 w-4 mr-1" />
              +2 today
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="dashboard-card lg:col-span-2">
          <CardHeader className="pb-4">
            <div className="flex justify-between items-center">
              <CardTitle>Revenue Trend</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">Week</Button>
                <Button variant="outline" size="sm">Month</Button>
                <Button variant="outline" size="sm">Year</Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <RevenueChart />
          </CardContent>
        </Card>

        <Card className="dashboard-card">
          <CardHeader className="pb-4">
            <CardTitle>Lead Sources</CardTitle>
          </CardHeader>
          <CardContent>
            <LeadSourceChart />
          </CardContent>
        </Card>
      </div>

      {/* Data Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="dashboard-card lg:col-span-2">
          <CardHeader className="pb-4">
            <div className="flex justify-between items-center">
              <CardTitle>Recent Leads</CardTitle>
              <Button size="sm">View All</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 font-medium">Name</th>
                    <th className="text-left py-3 font-medium">Company</th>
                    <th className="text-left py-3 font-medium">Source</th>
                    <th className="text-left py-3 font-medium">Status</th>
                    <th className="text-left py-3 font-medium">Value</th>
                    <th className="text-left py-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {leads.slice(0, 5).map((lead) => (
                    <tr key={lead.id} className="border-b border-border hover:bg-muted/50">
                      <td className="py-4">
                        <div className="flex items-center">
                          <div className="bg-primary rounded-full w-8 h-8 flex items-center justify-center mr-3">
                            <span className="text-primary-foreground text-sm font-semibold">
                              {lead.name.charAt(0)}
                            </span>
                          </div>
                          <div>
                            <div className="font-semibold">{lead.name}</div>
                            <div className="text-sm text-muted-foreground">{lead.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-4">{lead.company}</td>
                      <td className="py-4">{getSourceBadge(lead.source)}</td>
                      <td className="py-4">{getStatusBadge(lead.status)}</td>
                      <td className="py-4 font-semibold">${parseFloat(lead.value || "0").toLocaleString()}</td>
                      <td className="py-4">
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card className="dashboard-card">
          <CardHeader className="pb-4">
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
              <div className="flex">
                <div className="flex-shrink-0 mr-3">
                  <div className="bg-primary rounded-full w-8 h-8 flex items-center justify-center">
                    <Users className="h-4 w-4 text-primary-foreground" />
                  </div>
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-sm">New lead created</div>
                  <div className="text-sm text-muted-foreground">Jane Smith from Acme Corp</div>
                  <div className="text-xs text-muted-foreground">2 minutes ago</div>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 mr-3">
                  <div className="bg-green-500 rounded-full w-8 h-8 flex items-center justify-center">
                    <FileText className="h-4 w-4 text-white" />
                  </div>
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-sm">Quote approved</div>
                  <div className="text-sm text-muted-foreground">Enterprise Solutions - $125,000</div>
                  <div className="text-xs text-muted-foreground">15 minutes ago</div>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 mr-3">
                  <div className="bg-yellow-500 rounded-full w-8 h-8 flex items-center justify-center">
                    <LifeBuoy className="h-4 w-4 text-white" />
                  </div>
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-sm">Support ticket created</div>
                  <div className="text-sm text-muted-foreground">Login issues - Priority: High</div>
                  <div className="text-xs text-muted-foreground">1 hour ago</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
