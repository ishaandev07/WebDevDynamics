import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { 
  Menu, 
  Search, 
  Bell, 
  Moon, 
  Sun, 
  User, 
  Settings, 
  LogOut, 
  Grid3X3,
  UserPlus,
  FileText,
  LifeBuoy,
  BarChart3
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useNotifications } from "@/hooks/useNotifications";
import { useThemeContext } from "@/context/ThemeContext";
import { userShortcuts } from "@/lib/config";

interface HeaderProps {
  onSidebarToggle: () => void;
  onModuleChange: (module: string) => void;
}

export function Header({ onSidebarToggle, onModuleChange }: HeaderProps) {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useThemeContext();
  const { notifications, unreadCount, markAsRead } = useNotifications(user?.id || 0);
  const [searchQuery, setSearchQuery] = useState("");

  const shortcuts = user ? userShortcuts[user.role as keyof typeof userShortcuts] || [] : [];

  const handleShortcutAction = (action: string) => {
    switch (action) {
      case "createLead":
        onModuleChange("crm");
        break;
      case "createQuote":
        onModuleChange("cpq");
        break;
      case "createTicket":
        onModuleChange("support");
        break;
      case "viewReports":
        onModuleChange("finops");
        break;
      default:
        console.log(`Action: ${action}`);
    }
  };

  return (
    <header className="header bg-card border-b border-border px-6 flex items-center justify-between">
      <div className="flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden mr-3"
          onClick={onSidebarToggle}
        >
          <Menu className="h-5 w-5" />
        </Button>
        
        <div className="relative max-w-md flex-1 mr-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Shortcut Panel */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <Grid3X3 className="h-5 w-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-72">
            <DropdownMenuLabel>Quick Actions</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <div className="grid grid-cols-2 gap-2 p-2">
              {shortcuts.map((shortcut) => {
                const iconMap = {
                  UserPlus,
                  FileText,
                  LifeBuoy,
                  BarChart3
                };
                const Icon = iconMap[shortcut.icon as keyof typeof iconMap] || UserPlus;
                
                return (
                  <Button
                    key={shortcut.action}
                    variant="ghost"
                    className="h-auto p-3 flex flex-col items-center justify-center text-center"
                    onClick={() => handleShortcutAction(shortcut.action)}
                  >
                    <Icon className="h-4 w-4 mb-1" />
                    <span className="text-xs">{shortcut.name}</span>
                  </Button>
                );
              })}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <Badge className="notification-badge">
                  {unreadCount}
                </Badge>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel className="flex justify-between items-center">
              <span>Notifications</span>
              <span className="text-sm text-muted-foreground">{unreadCount} unread</span>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <div className="max-h-96 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-4 text-center text-muted-foreground">
                  No notifications
                </div>
              ) : (
                notifications.slice(0, 5).map((notification) => (
                  <DropdownMenuItem
                    key={notification.id}
                    className="p-4 cursor-pointer"
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex">
                      <div className="flex-shrink-0 mr-3">
                        <div className="bg-primary rounded-full w-8 h-8 flex items-center justify-center">
                          <Bell className="h-4 w-4 text-primary-foreground" />
                        </div>
                      </div>
                      <div className="flex-grow-1">
                        <div className="font-semibold text-sm">{notification.title}</div>
                        <div className="text-sm text-muted-foreground">{notification.message}</div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(notification.createdAt).toLocaleTimeString()}
                        </div>
                      </div>
                      {!notification.isRead && (
                        <div className="w-2 h-2 bg-primary rounded-full"></div>
                      )}
                    </div>
                  </DropdownMenuItem>
                ))
              )}
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-center text-primary">
              View all notifications
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Dark Mode Toggle */}
        <Button variant="ghost" size="icon" onClick={toggleTheme}>
          {theme === "dark" ? (
            <Sun className="h-5 w-5" />
          ) : (
            <Moon className="h-5 w-5" />
          )}
        </Button>

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>
              <div className="font-semibold">{user?.firstName} {user?.lastName}</div>
              <div className="text-sm text-muted-foreground capitalize">{user?.role?.replace('_', ' ')}</div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <User className="mr-2 h-4 w-4" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={logout} className="text-destructive">
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
