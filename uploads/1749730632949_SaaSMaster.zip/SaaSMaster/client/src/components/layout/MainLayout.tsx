import { useState, useEffect } from "react";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { cn } from "@/lib/utils";

interface MainLayoutProps {
  children: React.ReactNode;
  activeModule: string;
  onModuleChange: (module: string) => void;
}

export function MainLayout({ children, activeModule, onModuleChange }: MainLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const handleSidebarToggle = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  // Close sidebar on mobile when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (window.innerWidth <= 768) {
        const sidebar = document.querySelector('.sidebar');
        const target = event.target as HTMLElement;
        
        if (sidebar && !sidebar.contains(target) && !target.closest('[data-sidebar-toggle]')) {
          setSidebarCollapsed(true);
        }
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  return (
    <div className={cn("min-h-screen bg-background", sidebarCollapsed && "sidebar-collapsed")}>
      <Sidebar 
        activeModule={activeModule}
        onModuleChange={onModuleChange}
        isCollapsed={sidebarCollapsed}
      />
      
      <div className="main-content">
        <Header 
          onSidebarToggle={handleSidebarToggle}
          onModuleChange={onModuleChange}
        />
        
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
