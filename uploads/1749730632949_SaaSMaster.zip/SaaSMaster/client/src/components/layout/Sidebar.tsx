import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  LayoutDashboard, 
  Users, 
  Settings, 
  Tag, 
  FileText, 
  TrendingUp, 
  Headphones, 
  RefreshCw, 
  ShoppingCart, 
  Store, 
  UserPlus, 
  Sliders,
  Box
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { rolePermissions, moduleConfig } from "@/lib/config";
import { useLocation } from "wouter";

interface SidebarProps {
  activeModule: string;
  onModuleChange: (module: string) => void;
  isCollapsed: boolean;
}

const moduleIcons = {
  dashboard: LayoutDashboard,
  crm: Users,
  epc: Settings,
  pricebook: Tag,
  cpq: FileText,
  finops: TrendingUp,
  support: Headphones,
  subscriptions: RefreshCw,
  orders: ShoppingCart,
  marketplace: Store,
  onboarding: UserPlus,
  admin: Sliders,
};

export function Sidebar({ activeModule, onModuleChange, isCollapsed }: SidebarProps) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  
  const allowedModules = user ? rolePermissions[user.role as keyof typeof rolePermissions] || [] : [];
  
  const navigationItems = [
    { id: "dashboard", name: "Dashboard", icon: LayoutDashboard },
    ...Object.entries(moduleConfig).map(([key, config]) => ({
      id: key,
      name: config.name,
      icon: moduleIcons[key as keyof typeof moduleIcons],
    })).filter(item => allowedModules.includes(item.id))
  ];

  const handleNavigation = (moduleId: string) => {
    setLocation(`/${moduleId}`);
    onModuleChange(moduleId);
  };

  return (
    <div className={cn(
      "sidebar",
      isCollapsed && "sidebar-collapsed"
    )}>
      {/* Brand */}
      <div className="px-6 py-6 border-b border-white/10">
        <div className="flex items-center">
          <div className="bg-primary rounded-full w-10 h-10 flex items-center justify-center mr-3">
            <Box className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <h5 className="text-white font-semibold text-lg mb-0">Enterprise SaaS</h5>
            <small className="text-slate-400">Platform</small>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 py-4">
        <nav className="px-4 space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeModule === item.id;
            
            return (
              <Button
                key={item.id}
                variant="ghost"
                className={cn(
                  "nav-link w-full justify-start",
                  isActive && "active"
                )}
                onClick={() => handleNavigation(item.id)}
              >
                <Icon className="h-5 w-5 mr-3" />
                <span>{item.name}</span>
              </Button>
            );
          })}
        </nav>
      </ScrollArea>
    </div>
  );
}
