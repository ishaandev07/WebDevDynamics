export interface AppConfig {
  brandName: string;
  logoPath?: string;
  primaryColor: string;
  secondaryColor: string;
  enabledModules: string[];
  darkMode: boolean;
}

export const defaultConfig: AppConfig = {
  brandName: "Enterprise SaaS",
  logoPath: undefined,
  primaryColor: "#2563eb",
  secondaryColor: "#64748b",
  enabledModules: [
    "crm",
    "epc", 
    "pricebook",
    "cpq",
    "finops",
    "support",
    "subscriptions",
    "orders",
    "marketplace",
    "onboarding"
  ],
  darkMode: false,
};

export const moduleConfig = {
  crm: {
    name: "CRM",
    icon: "Users",
    description: "Customer Relationship Management",
  },
  epc: {
    name: "Product Config",
    icon: "Settings",
    description: "Enterprise Product Configurator",
  },
  pricebook: {
    name: "Pricebook",
    icon: "Tag",
    description: "Pricing Management",
  },
  cpq: {
    name: "Quotes (CPQ)",
    icon: "FileText",
    description: "Configure, Price, Quote",
  },
  finops: {
    name: "FinOps",
    icon: "TrendingUp",
    description: "Financial Operations",
  },
  support: {
    name: "Support",
    icon: "Headphones",
    description: "Customer Support System",
  },
  subscriptions: {
    name: "Subscriptions",
    icon: "RefreshCw",
    description: "Subscription Management",
  },
  orders: {
    name: "Orders",
    icon: "ShoppingCart",
    description: "Order Management",
  },
  marketplace: {
    name: "Marketplace",
    icon: "Store",
    description: "Product Marketplace",
  },
  onboarding: {
    name: "Onboarding",
    icon: "UserPlus",
    description: "Partner & Customer Onboarding",
  },
  admin: {
    name: "Admin Settings",
    icon: "Sliders",
    description: "System Administration",
  },
};

export const rolePermissions = {
  admin: ["crm", "epc", "pricebook", "cpq", "finops", "support", "subscriptions", "orders", "marketplace", "onboarding", "admin"],
  sales: ["crm", "cpq", "orders", "marketplace"],
  account_manager: ["crm", "cpq", "support", "subscriptions", "orders"],
  customer: ["support", "subscriptions", "orders", "marketplace"],
  partner: ["marketplace", "onboarding", "support"],
};

export const userShortcuts = {
  admin: [
    { name: "New Lead", icon: "UserPlus", action: "createLead" },
    { name: "Create Quote", icon: "FileText", action: "createQuote" },
    { name: "New Ticket", icon: "LifeBuoy", action: "createTicket" },
    { name: "Reports", icon: "BarChart3", action: "viewReports" },
  ],
  sales: [
    { name: "New Lead", icon: "UserPlus", action: "createLead" },
    { name: "Create Quote", icon: "FileText", action: "createQuote" },
    { name: "Pipeline", icon: "TrendingUp", action: "viewPipeline" },
    { name: "Products", icon: "Package", action: "viewProducts" },
  ],
  account_manager: [
    { name: "New Ticket", icon: "LifeBuoy", action: "createTicket" },
    { name: "Customer View", icon: "Users", action: "viewCustomers" },
    { name: "Renewals", icon: "RefreshCw", action: "viewRenewals" },
    { name: "Reports", icon: "BarChart3", action: "viewReports" },
  ],
  customer: [
    { name: "New Ticket", icon: "LifeBuoy", action: "createTicket" },
    { name: "Orders", icon: "ShoppingCart", action: "viewOrders" },
    { name: "Billing", icon: "CreditCard", action: "viewBilling" },
    { name: "Downloads", icon: "Download", action: "viewDownloads" },
  ],
  partner: [
    { name: "Marketplace", icon: "Store", action: "viewMarketplace" },
    { name: "Commission", icon: "DollarSign", action: "viewCommission" },
    { name: "Resources", icon: "BookOpen", action: "viewResources" },
    { name: "Support", icon: "LifeBuoy", action: "createTicket" },
  ],
};
