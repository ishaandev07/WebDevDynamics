# Configuration and Customization Guide

This guide covers how to configure and customize the frontend application to match your brand and requirements.

## Table of Contents

1. [Application Configuration](#application-configuration)
2. [Branding and Theming](#branding-and-theming)
3. [Module Configuration](#module-configuration)
4. [Environment Variables](#environment-variables)
5. [UI Customization](#ui-customization)
6. [Feature Flags](#feature-flags)
7. [Internationalization](#internationalization)

## Application Configuration

### Main Configuration File

The primary configuration is located in `src/lib/config.ts`:

```typescript
export interface AppConfig {
  brandName: string;
  logoPath?: string;
  primaryColor: string;
  secondaryColor: string;
  enabledModules: string[];
  darkMode: boolean;
}

export const defaultConfig: AppConfig = {
  brandName: "Enterprise SaaS",
  logoPath: "/assets/logo.png",
  primaryColor: "#3b82f6",
  secondaryColor: "#64748b",
  enabledModules: [
    "DASHBOARD",
    "CRM", 
    "EPC",
    "PRICEBOOK",
    "CPQ",
    "FINOPS",
    "SUPPORT",
    "SUBSCRIPTIONS",
    "ORDERS",
    "MARKETPLACE",
    "ONBOARDING",
    "ADMIN"
  ],
  darkMode: true
};
```

### Module Configuration

Available modules and their configurations:

```typescript
export const moduleConfig = {
  DASHBOARD: {
    name: "Dashboard",
    icon: "LayoutDashboard",
    path: "/dashboard",
    description: "Main analytics and overview",
    permissions: ["VIEW_DASHBOARD"]
  },
  CRM: {
    name: "CRM",
    icon: "Users",
    path: "/crm",
    description: "Customer relationship management",
    permissions: ["VIEW_CRM", "MANAGE_LEADS"]
  },
  EPC: {
    name: "EPC",
    icon: "Briefcase",
    path: "/epc",
    description: "Enterprise partner center",
    permissions: ["VIEW_EPC"]
  },
  PRICEBOOK: {
    name: "Pricebook",
    icon: "DollarSign",
    path: "/pricebook",
    description: "Product pricing management",
    permissions: ["VIEW_PRICEBOOK", "MANAGE_PRICING"]
  },
  CPQ: {
    name: "CPQ",
    icon: "Calculator",
    path: "/cpq",
    description: "Configure, price, quote",
    permissions: ["VIEW_CPQ", "CREATE_QUOTES"]
  },
  FINOPS: {
    name: "FinOps",
    icon: "TrendingUp",
    path: "/finops",
    description: "Financial operations",
    permissions: ["VIEW_FINOPS", "MANAGE_FINANCE"]
  },
  SUPPORT: {
    name: "Support",
    icon: "HelpCircle",
    path: "/support",
    description: "Customer support system",
    permissions: ["VIEW_SUPPORT", "MANAGE_TICKETS"]
  },
  SUBSCRIPTIONS: {
    name: "Subscriptions",
    icon: "RefreshCw",
    path: "/subscriptions",
    description: "Subscription management",
    permissions: ["VIEW_SUBSCRIPTIONS"]
  },
  ORDERS: {
    name: "Orders",
    icon: "ShoppingCart",
    path: "/orders",
    description: "Order management",
    permissions: ["VIEW_ORDERS"]
  },
  MARKETPLACE: {
    name: "Marketplace",
    icon: "Store",
    path: "/marketplace",
    description: "Product marketplace",
    permissions: ["VIEW_MARKETPLACE"]
  },
  ONBOARDING: {
    name: "Onboarding",
    icon: "UserPlus",
    path: "/onboarding",
    description: "User onboarding flows",
    permissions: ["VIEW_ONBOARDING"]
  },
  ADMIN: {
    name: "Admin",
    icon: "Settings",
    path: "/admin",
    description: "System administration",
    permissions: ["ADMIN_ACCESS"]
  }
};
```

### Role-Based Permissions

Configure which roles have access to which features:

```typescript
export const rolePermissions = {
  ADMIN: [
    "VIEW_DASHBOARD", "VIEW_CRM", "MANAGE_LEADS", "VIEW_EPC", 
    "VIEW_PRICEBOOK", "MANAGE_PRICING", "VIEW_CPQ", "CREATE_QUOTES",
    "VIEW_FINOPS", "MANAGE_FINANCE", "VIEW_SUPPORT", "MANAGE_TICKETS",
    "VIEW_SUBSCRIPTIONS", "VIEW_ORDERS", "VIEW_MARKETPLACE", 
    "VIEW_ONBOARDING", "ADMIN_ACCESS"
  ],
  MANAGER: [
    "VIEW_DASHBOARD", "VIEW_CRM", "MANAGE_LEADS", "VIEW_PRICEBOOK",
    "VIEW_CPQ", "CREATE_QUOTES", "VIEW_FINOPS", "VIEW_SUPPORT",
    "MANAGE_TICKETS", "VIEW_SUBSCRIPTIONS", "VIEW_ORDERS"
  ],
  SALES: [
    "VIEW_DASHBOARD", "VIEW_CRM", "MANAGE_LEADS", "VIEW_PRICEBOOK",
    "VIEW_CPQ", "CREATE_QUOTES", "VIEW_SUPPORT"
  ],
  SUPPORT: [
    "VIEW_DASHBOARD", "VIEW_CRM", "VIEW_SUPPORT", "MANAGE_TICKETS",
    "VIEW_SUBSCRIPTIONS", "VIEW_ORDERS"
  ]
};
```

## Branding and Theming

### Primary Brand Configuration

Update your brand identity in the configuration:

```typescript
// Update in src/lib/config.ts
export const brandConfig = {
  brandName: "Your Company Name",
  logoPath: "/assets/your-logo.png",
  faviconPath: "/assets/favicon.ico",
  primaryColor: "#059669", // Your brand primary color
  secondaryColor: "#6b7280", // Your brand secondary color
  accentColor: "#f59e0b", // Accent color for highlights
};
```

### Color Theme System

The application uses CSS custom properties for theming. Update `src/index.css`:

```css
:root {
  /* Brand Colors */
  --primary: 5 150 105; /* RGB values for primary color */
  --primary-foreground: 255 255 255;
  --secondary: 107 114 128;
  --secondary-foreground: 15 23 42;
  --accent: 245 158 11;
  --accent-foreground: 15 23 42;
  
  /* Semantic Colors */
  --background: 255 255 255;
  --foreground: 15 23 42;
  --card: 255 255 255;
  --card-foreground: 15 23 42;
  --border: 226 232 240;
  --input: 226 232 240;
  --ring: 5 150 105;
  
  /* Status Colors */
  --success: 34 197 94;
  --warning: 245 158 11;
  --error: 239 68 68;
  --info: 59 130 246;
}

.dark {
  /* Dark mode variants */
  --background: 8 8 8;
  --foreground: 250 250 250;
  --card: 15 15 15;
  --card-foreground: 250 250 250;
  --border: 39 39 42;
  --input: 39 39 42;
  --ring: 5 150 105;
}
```

### Custom Logo Implementation

1. Add your logo files to `public/assets/`:
   - `logo.png` - Main logo (recommended: 200x50px)
   - `logo-dark.png` - Dark mode variant
   - `favicon.ico` - Browser favicon

2. Update the logo component in `src/components/layout/Header.tsx`:

```typescript
const Logo = () => {
  const { theme } = useTheme();
  const logoSrc = theme === 'dark' ? '/assets/logo-dark.png' : '/assets/logo.png';
  
  return (
    <img 
      src={logoSrc} 
      alt={brandConfig.brandName}
      className="h-8 w-auto"
    />
  );
};
```

### Typography Configuration

Customize fonts in `tailwind.config.ts`:

```typescript
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        serif: ['Georgia', 'serif'],
        mono: ['Monaco', 'Consolas', 'monospace'],
      },
    },
  },
};
```

## Module Configuration

### Enabling/Disabling Modules

Control which modules are available to users:

```typescript
// In src/lib/config.ts
export const enabledModules = [
  "DASHBOARD",
  "CRM",
  "SUPPORT",
  // Remove modules you don't need
  // "EPC",
  // "MARKETPLACE",
];
```

### Custom Module Routes

Add custom modules by updating the routing in `src/App.tsx`:

```typescript
// Add your custom module
import { CustomModule } from "@/pages/custom/CustomModule";

// In the routing section
<Route path="/custom" component={CustomModule} />
```

### Module-Specific Configuration

Configure individual modules:

```typescript
// CRM Module Configuration
export const crmConfig = {
  leadSources: ["WEBSITE", "EMAIL", "PHONE", "REFERRAL", "SOCIAL_MEDIA"],
  leadStatuses: ["NEW", "CONTACTED", "QUALIFIED", "LOST", "WON"],
  defaultAssignee: null,
  autoAssignment: true,
  notifications: {
    newLead: true,
    statusChange: true,
    assignment: true
  }
};

// Support Module Configuration
export const supportConfig = {
  priorities: ["LOW", "MEDIUM", "HIGH", "URGENT"],
  categories: ["TECHNICAL", "BILLING", "GENERAL", "FEATURE_REQUEST"],
  slaHours: {
    LOW: 72,
    MEDIUM: 24,
    HIGH: 8,
    URGENT: 2
  },
  autoEscalation: true
};
```

## Environment Variables

### Development Environment

Create `.env.local`:

```env
# API Configuration
VITE_API_BASE_URL=http://localhost:8080/api
VITE_WS_URL=ws://localhost:8080/ws

# Application Settings
VITE_APP_NAME=Enterprise SaaS
VITE_APP_VERSION=1.0.0
VITE_ENVIRONMENT=development

# Feature Flags
VITE_ENABLE_ANALYTICS=false
VITE_ENABLE_ERROR_REPORTING=false
VITE_ENABLE_BETA_FEATURES=true

# Third-party Services (optional)
VITE_GOOGLE_ANALYTICS_ID=
VITE_SENTRY_DSN=
VITE_INTERCOM_APP_ID=
```

### Production Environment

Create `.env.production`:

```env
# API Configuration
VITE_API_BASE_URL=https://api.your-domain.com/api
VITE_WS_URL=wss://api.your-domain.com/ws

# Application Settings
VITE_APP_NAME=Your Enterprise SaaS
VITE_APP_VERSION=1.0.0
VITE_ENVIRONMENT=production

# Feature Flags
VITE_ENABLE_ANALYTICS=true
VITE_ENABLE_ERROR_REPORTING=true
VITE_ENABLE_BETA_FEATURES=false

# Third-party Services
VITE_GOOGLE_ANALYTICS_ID=GA-XXXXXXXXX
VITE_SENTRY_DSN=https://your-sentry-dsn
```

### Using Environment Variables

Access environment variables in your code:

```typescript
// src/lib/env.ts
export const env = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL,
  appName: import.meta.env.VITE_APP_NAME,
  environment: import.meta.env.VITE_ENVIRONMENT,
  enableAnalytics: import.meta.env.VITE_ENABLE_ANALYTICS === 'true',
  enableErrorReporting: import.meta.env.VITE_ENABLE_ERROR_REPORTING === 'true',
};
```

## UI Customization

### Component Styling

Customize UI components using Tailwind CSS classes:

```typescript
// Custom button variants
const buttonVariants = cva(
  "inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        outline: "border border-input hover:bg-accent hover:text-accent-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        // Add your custom variants
        brand: "bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700",
      },
    },
  }
);
```

### Layout Customization

Modify the main layout in `src/components/layout/MainLayout.tsx`:

```typescript
// Custom sidebar width
const SIDEBAR_WIDTH = {
  collapsed: 'w-16',
  expanded: 'w-64', // Customize width
};

// Custom header height
const HEADER_HEIGHT = 'h-16'; // Customize height
```

### Dashboard Customization

Customize the dashboard layout in `src/pages/dashboard/Dashboard.tsx`:

```typescript
// Custom dashboard grid
const dashboardLayout = {
  columns: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4',
  gap: 'gap-6',
  padding: 'p-6',
};

// Custom widget configurations
const widgetConfig = {
  revenue: { span: 'col-span-2', height: 'h-80' },
  leads: { span: 'col-span-1', height: 'h-40' },
  orders: { span: 'col-span-1', height: 'h-40' },
  // Add your custom widgets
};
```

## Feature Flags

### Implementation

Create a feature flag system:

```typescript
// src/lib/featureFlags.ts
export interface FeatureFlags {
  enableBetaFeatures: boolean;
  enableAdvancedAnalytics: boolean;
  enableAIAssistant: boolean;
  enableMobileApp: boolean;
}

export const featureFlags: FeatureFlags = {
  enableBetaFeatures: import.meta.env.VITE_ENABLE_BETA_FEATURES === 'true',
  enableAdvancedAnalytics: import.meta.env.VITE_ENABLE_ADVANCED_ANALYTICS === 'true',
  enableAIAssistant: import.meta.env.VITE_ENABLE_AI_ASSISTANT === 'true',
  enableMobileApp: import.meta.env.VITE_ENABLE_MOBILE_APP === 'true',
};

// Feature flag hook
export const useFeatureFlag = (flag: keyof FeatureFlags): boolean => {
  return featureFlags[flag];
};
```

### Usage in Components

```typescript
// Use feature flags in components
const MyComponent = () => {
  const enableBetaFeatures = useFeatureFlag('enableBetaFeatures');
  
  return (
    <div>
      {enableBetaFeatures && (
        <BetaFeatureComponent />
      )}
      <StandardComponent />
    </div>
  );
};
```

## Internationalization

### Setup i18n

Install and configure internationalization:

```bash
npm install react-i18next i18next
```

```typescript
// src/lib/i18n.ts
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        translation: {
          dashboard: "Dashboard",
          crm: "CRM",
          support: "Support",
          // Add your translations
        }
      },
      es: {
        translation: {
          dashboard: "Panel de Control",
          crm: "CRM",
          support: "Soporte",
          // Add Spanish translations
        }
      }
    },
    lng: "en",
    fallbackLng: "en",
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
```

### Usage in Components

```typescript
import { useTranslation } from 'react-i18next';

const MyComponent = () => {
  const { t } = useTranslation();
  
  return (
    <h1>{t('dashboard')}</h1>
  );
};
```

## Performance Configuration

### Bundle Optimization

Configure Vite for optimal performance:

```typescript
// vite.config.ts
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          ui: ['@radix-ui/react-dialog', '@radix-ui/react-dropdown-menu'],
          charts: ['recharts', 'chart.js'],
        }
      }
    },
    chunkSizeWarningLimit: 1000,
  },
  optimizeDeps: {
    include: ['react', 'react-dom'],
  },
});
```

### Lazy Loading Configuration

```typescript
// Configure lazy loading for pages
const lazyPageConfig = {
  suspenseFallback: <PageSkeleton />,
  errorBoundary: <PageErrorBoundary />,
  retryAttempts: 3,
};
```

This configuration guide provides comprehensive customization options for adapting the frontend to your specific needs and brand requirements.