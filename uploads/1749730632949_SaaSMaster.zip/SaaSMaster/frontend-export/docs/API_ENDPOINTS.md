# API Endpoints Documentation

This document defines all the REST API endpoints that your Java backend must implement to support the frontend application.

## Base URL Structure

```
Base URL: {protocol}://{host}:{port}/api
Example: http://localhost:8080/api
```

## Authentication Endpoints

### POST /auth/login
Authenticate user and return access token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response (200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "johndoe",
    "email": "user@example.com",
    "role": "ADMIN",
    "createdAt": "2024-01-01T00:00:00Z"
  }
}
```

### POST /auth/register
Register a new user account.

**Request Body:**
```json
{
  "username": "johndoe",
  "email": "user@example.com",
  "password": "password123",
  "role": "SALES"
}
```

**Response (201):**
```json
{
  "id": 1,
  "username": "johndoe",
  "email": "user@example.com",
  "role": "SALES",
  "createdAt": "2024-01-01T00:00:00Z"
}
```

### POST /auth/logout
Logout current user (invalidate token/session).

**Response (200):**
```json
{
  "message": "Logged out successfully"
}
```

### GET /auth/user
Get current authenticated user information.

**Headers:** `Authorization: Bearer {token}`

**Response (200):**
```json
{
  "id": 1,
  "username": "johndoe",
  "email": "user@example.com",
  "role": "ADMIN",
  "createdAt": "2024-01-01T00:00:00Z"
}
```

## User Management Endpoints

### GET /users
Get all users (Admin only).

**Response (200):**
```json
[
  {
    "id": 1,
    "username": "johndoe",
    "email": "user@example.com",
    "role": "ADMIN",
    "createdAt": "2024-01-01T00:00:00Z"
  }
]
```

### GET /users/{id}
Get user by ID.

**Response (200):**
```json
{
  "id": 1,
  "username": "johndoe",
  "email": "user@example.com",
  "role": "ADMIN",
  "createdAt": "2024-01-01T00:00:00Z"
}
```

### PUT /users/{id}
Update user information.

**Request Body:**
```json
{
  "username": "johnsmith",
  "email": "johnsmith@example.com",
  "role": "MANAGER"
}
```

### DELETE /users/{id}
Delete user (Admin only).

**Response (204):** No content

## Lead Management Endpoints

### GET /leads
Get all leads with optional filtering.

**Query Parameters:**
- `status`: Filter by status (NEW, CONTACTED, QUALIFIED, LOST, WON)
- `assignedTo`: Filter by assigned user ID
- `page`: Page number (default: 0)
- `size`: Page size (default: 20)

**Response (200):**
```json
{
  "content": [
    {
      "id": 1,
      "firstName": "Jane",
      "lastName": "Doe",
      "email": "jane.doe@company.com",
      "phone": "+1234567890",
      "company": "Acme Corp",
      "status": "NEW",
      "source": "WEBSITE",
      "value": 50000.00,
      "assignedTo": 1,
      "notes": "Interested in enterprise package",
      "createdAt": "2024-01-01T00:00:00Z",
      "updatedAt": "2024-01-01T00:00:00Z"
    }
  ],
  "totalElements": 1,
  "totalPages": 1,
  "number": 0,
  "size": 20
}
```

### POST /leads
Create new lead.

**Request Body:**
```json
{
  "firstName": "Jane",
  "lastName": "Doe",
  "email": "jane.doe@company.com",
  "phone": "+1234567890",
  "company": "Acme Corp",
  "source": "WEBSITE",
  "value": 50000.00,
  "notes": "Interested in enterprise package"
}
```

### PUT /leads/{id}
Update lead information.

**Request Body:**
```json
{
  "status": "QUALIFIED",
  "assignedTo": 2,
  "value": 75000.00,
  "notes": "Updated after qualification call"
}
```

### DELETE /leads/{id}
Delete lead.

**Response (204):** No content

## Quote Management Endpoints

### GET /quotes
Get all quotes.

**Response (200):**
```json
[
  {
    "id": 1,
    "leadId": 1,
    "quoteNumber": "Q-2024-001",
    "status": "DRAFT",
    "validUntil": "2024-02-01T00:00:00Z",
    "totalAmount": 15000.00,
    "items": [
      {
        "productId": 1,
        "productName": "Enterprise License",
        "quantity": 1,
        "unitPrice": 10000.00,
        "discount": 0.10,
        "totalPrice": 9000.00
      }
    ],
    "createdAt": "2024-01-01T00:00:00Z"
  }
]
```

### POST /quotes
Create new quote.

**Request Body:**
```json
{
  "leadId": 1,
  "validUntil": "2024-02-01T00:00:00Z",
  "items": [
    {
      "productId": 1,
      "quantity": 1,
      "unitPrice": 10000.00,
      "discount": 0.10
    }
  ],
  "notes": "Special enterprise pricing"
}
```

### PUT /quotes/{id}
Update quote.

### DELETE /quotes/{id}
Delete quote.

## Product Management Endpoints

### GET /products
Get all products.

**Response (200):**
```json
[
  {
    "id": 1,
    "name": "Enterprise License",
    "description": "Full-featured enterprise software license",
    "category": "SOFTWARE",
    "price": 10000.00,
    "isActive": true,
    "createdAt": "2024-01-01T00:00:00Z"
  }
]
```

### POST /products
Create new product.

**Request Body:**
```json
{
  "name": "Enterprise License",
  "description": "Full-featured enterprise software license",
  "category": "SOFTWARE",
  "price": 10000.00,
  "isActive": true
}
```

### PUT /products/{id}
Update product.

### DELETE /products/{id}
Delete product.

## Support Ticket Endpoints

### GET /support/tickets
Get support tickets.

**Query Parameters:**
- `status`: Filter by status (OPEN, IN_PROGRESS, RESOLVED, CLOSED)
- `priority`: Filter by priority (LOW, MEDIUM, HIGH, URGENT)
- `assignedTo`: Filter by assigned user ID

**Response (200):**
```json
[
  {
    "id": 1,
    "title": "Login Issue",
    "description": "Cannot access dashboard",
    "status": "OPEN",
    "priority": "HIGH",
    "customerId": 1,
    "assignedTo": 2,
    "createdAt": "2024-01-01T00:00:00Z",
    "updatedAt": "2024-01-01T00:00:00Z"
  }
]
```

### POST /support/tickets
Create support ticket.

**Request Body:**
```json
{
  "title": "Login Issue",
  "description": "Cannot access dashboard",
  "priority": "HIGH",
  "customerId": 1
}
```

### PUT /support/tickets/{id}
Update support ticket.

### DELETE /support/tickets/{id}
Delete support ticket.

## Subscription Management Endpoints

### GET /subscriptions
Get all subscriptions.

**Response (200):**
```json
[
  {
    "id": 1,
    "customerId": 1,
    "planName": "Enterprise Plan",
    "status": "ACTIVE",
    "startDate": "2024-01-01T00:00:00Z",
    "endDate": "2024-12-31T23:59:59Z",
    "monthlyAmount": 999.00,
    "isRecurring": true,
    "createdAt": "2024-01-01T00:00:00Z"
  }
]
```

### POST /subscriptions
Create subscription.

### PUT /subscriptions/{id}
Update subscription.

### DELETE /subscriptions/{id}
Cancel subscription.

## Order Management Endpoints

### GET /orders
Get all orders.

**Response (200):**
```json
[
  {
    "id": 1,
    "customerId": 1,
    "orderNumber": "ORD-2024-001",
    "status": "COMPLETED",
    "totalAmount": 15000.00,
    "items": [
      {
        "productId": 1,
        "productName": "Enterprise License",
        "quantity": 1,
        "unitPrice": 15000.00,
        "totalPrice": 15000.00
      }
    ],
    "orderDate": "2024-01-01T00:00:00Z",
    "deliveryDate": "2024-01-15T00:00:00Z"
  }
]
```

### POST /orders
Create new order.

### PUT /orders/{id}
Update order.

### DELETE /orders/{id}
Cancel order.

## Notification Endpoints

### GET /notifications
Get user notifications.

**Query Parameters:**
- `unreadOnly`: Get only unread notifications (boolean)

**Response (200):**
```json
[
  {
    "id": 1,
    "userId": 1,
    "title": "New Lead Assigned",
    "message": "You have been assigned a new lead: Jane Doe",
    "type": "LEAD_ASSIGNMENT",
    "isRead": false,
    "createdAt": "2024-01-01T00:00:00Z"
  }
]
```

### PUT /notifications/{id}/read
Mark notification as read.

**Response (200):**
```json
{
  "message": "Notification marked as read"
}
```

### GET /notifications/unread-count
Get count of unread notifications.

**Response (200):**
```json
{
  "count": 5
}
```

## Configuration Endpoints

### GET /config
Get application configuration.

**Response (200):**
```json
{
  "brandName": "Enterprise SaaS",
  "logoPath": "/assets/logo.png",
  "primaryColor": "#3b82f6",
  "secondaryColor": "#64748b",
  "enabledModules": ["CRM", "EPC", "CPQ", "SUPPORT"],
  "darkMode": true
}
```

### PUT /config
Update application configuration (Admin only).

**Request Body:**
```json
{
  "brandName": "My Company SaaS",
  "primaryColor": "#059669",
  "enabledModules": ["CRM", "SUPPORT"]
}
```

## Analytics Endpoints

### GET /analytics/revenue
Get revenue analytics data.

**Query Parameters:**
- `period`: Time period (WEEK, MONTH, QUARTER, YEAR)
- `startDate`: Start date (ISO format)
- `endDate`: End date (ISO format)

**Response (200):**
```json
{
  "period": "MONTH",
  "data": [
    {
      "date": "2024-01-01",
      "revenue": 45000.00,
      "orders": 15
    }
  ],
  "totalRevenue": 450000.00,
  "growth": 12.5
}
```

### GET /analytics/leads
Get lead analytics data.

**Response (200):**
```json
{
  "totalLeads": 150,
  "newLeads": 25,
  "conversionRate": 15.2,
  "sources": [
    {
      "source": "WEBSITE",
      "count": 75,
      "percentage": 50.0
    }
  ]
}
```

## Error Response Format

All endpoints should return consistent error responses:

**400 Bad Request:**
```json
{
  "error": "Bad Request",
  "message": "Invalid input data",
  "timestamp": "2024-01-01T00:00:00Z",
  "path": "/api/leads"
}
```

**401 Unauthorized:**
```json
{
  "error": "Unauthorized",
  "message": "Authentication required",
  "timestamp": "2024-01-01T00:00:00Z",
  "path": "/api/leads"
}
```

**403 Forbidden:**
```json
{
  "error": "Forbidden",
  "message": "Insufficient permissions",
  "timestamp": "2024-01-01T00:00:00Z",
  "path": "/api/users"
}
```

**404 Not Found:**
```json
{
  "error": "Not Found",
  "message": "Resource not found",
  "timestamp": "2024-01-01T00:00:00Z",
  "path": "/api/leads/999"
}
```

**500 Internal Server Error:**
```json
{
  "error": "Internal Server Error",
  "message": "An unexpected error occurred",
  "timestamp": "2024-01-01T00:00:00Z",
  "path": "/api/leads"
}
```

## Data Types Reference

### Enums

**UserRole:**
- `ADMIN` - System administrator
- `MANAGER` - Department manager
- `SALES` - Sales representative
- `SUPPORT` - Support agent

**LeadStatus:**
- `NEW` - New lead
- `CONTACTED` - Initial contact made
- `QUALIFIED` - Lead qualified
- `LOST` - Lead lost
- `WON` - Lead converted

**LeadSource:**
- `WEBSITE` - Company website
- `EMAIL` - Email campaign
- `PHONE` - Phone call
- `REFERRAL` - Customer referral
- `SOCIAL_MEDIA` - Social media
- `OTHER` - Other sources

**QuoteStatus:**
- `DRAFT` - Draft quote
- `SENT` - Sent to customer
- `ACCEPTED` - Accepted by customer
- `REJECTED` - Rejected by customer
- `EXPIRED` - Quote expired

**TicketStatus:**
- `OPEN` - New ticket
- `IN_PROGRESS` - Being worked on
- `RESOLVED` - Issue resolved
- `CLOSED` - Ticket closed

**TicketPriority:**
- `LOW` - Low priority
- `MEDIUM` - Medium priority
- `HIGH` - High priority
- `URGENT` - Urgent priority

**OrderStatus:**
- `PENDING` - Order pending
- `PROCESSING` - Being processed
- `COMPLETED` - Order completed
- `CANCELLED` - Order cancelled

**SubscriptionStatus:**
- `ACTIVE` - Active subscription
- `SUSPENDED` - Temporarily suspended
- `CANCELLED` - Cancelled subscription
- `EXPIRED` - Expired subscription