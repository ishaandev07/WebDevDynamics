# Quick Start Guide

Get your Enterprise SaaS frontend running with Java backend in minutes.

## Prerequisites

- Node.js 18+ and npm
- Java 11+ or 17+
- Your Java backend application

## Step 1: Install Dependencies

```bash
cd frontend-export
npm install
```

## Step 2: Configure Environment

Copy the example environment file:

```bash
cp .env.example .env.local
```

Edit `.env.local` to match your Java backend:

```env
VITE_API_BASE_URL=http://localhost:8080/api
VITE_APP_NAME=Your Company SaaS
```

## Step 3: Start Development Server

```bash
npm run dev
```

The frontend will be available at `http://localhost:5173`

## Step 4: Verify Integration

1. Ensure your Java backend is running on port 8080
2. Check API calls in browser developer tools
3. Test authentication flow
4. Verify data displays correctly

## Common Issues

**CORS Errors**: Configure CORS in your Java backend
**401 Errors**: Check authentication token format
**Connection Refused**: Verify backend is running on correct port

## Next Steps

- Review `JAVA_INTEGRATION.md` for detailed backend setup
- Check `API_ENDPOINTS.md` for required endpoints
- Customize branding in `CONFIGURATION.md`