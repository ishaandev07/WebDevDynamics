# Deployment Guide

This guide covers various deployment strategies for the React frontend with Java backend integration.

## Table of Contents

1. [Development Environment](#development-environment)
2. [Production Build](#production-build)
3. [Deployment Options](#deployment-options)
4. [Environment Configuration](#environment-configuration)
5. [Performance Optimization](#performance-optimization)
6. [Monitoring and Logging](#monitoring-and-logging)

## Development Environment

### Prerequisites
- Node.js 18+ and npm
- Java 11+ or 17+
- Your Java backend application

### Local Development Setup

1. **Start Java Backend:**
```bash
cd your-java-backend
./mvnw spring-boot:run
# Backend runs on http://localhost:8080
```

2. **Start Frontend Development Server:**
```bash
cd frontend-export
npm install
npm run dev
# Frontend runs on http://localhost:5173
```

3. **Verify Integration:**
- Frontend should proxy API calls to backend
- Authentication should work between services
- CORS should be properly configured

## Production Build

### 1. Build Frontend

```bash
cd frontend-export
npm run build
```

This creates a `dist/` directory with optimized static files.

### 2. Build Output Structure

```
dist/
├── index.html
├── assets/
│   ├── index-[hash].js
│   ├── index-[hash].css
│   └── [various asset files]
└── [other static files]
```

### 3. Build Verification

```bash
# Preview the production build locally
npm run preview
```

## Deployment Options

### Option 1: Serve Frontend from Java Backend (Recommended)

#### Step 1: Copy Built Files to Java Resources

```bash
# Copy frontend build to Java backend
cp -r frontend-export/dist/* your-java-backend/src/main/resources/static/
```

#### Step 2: Configure Spring Boot for Static Resources

```java
@Configuration
public class WebConfig implements WebMvcConfigurer {
    
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/static/")
                .setCachePeriod(3600)
                .resourceChain(true)
                .addResolver(new PathResourceResolver() {
                    @Override
                    protected Resource getResource(String resourcePath, Resource location) throws IOException {
                        Resource requestedResource = location.createRelative(resourcePath);
                        
                        // Serve index.html for client-side routes
                        return requestedResource.exists() && requestedResource.isReadable() 
                                ? requestedResource 
                                : new ClassPathResource("/static/index.html");
                    }
                });
    }
}
```

#### Step 3: Build and Deploy

```bash
# Build Java application with frontend included
cd your-java-backend
./mvnw clean package

# Deploy the JAR file
java -jar target/your-app.jar
```

### Option 2: Separate Frontend and Backend Deployments

#### Frontend Deployment (Nginx)

```nginx
# /etc/nginx/sites-available/your-app
server {
    listen 80;
    server_name your-domain.com;
    
    root /var/www/your-app/dist;
    index index.html;
    
    # Handle client-side routing
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Proxy API requests to Java backend
    location /api/ {
        proxy_pass http://backend-server:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

#### Deploy Frontend

```bash
# Deploy to web server
scp -r dist/* user@server:/var/www/your-app/
sudo systemctl reload nginx
```

### Option 3: Docker Deployment

#### Multi-stage Dockerfile

```dockerfile
# Stage 1: Build Frontend
FROM node:18-alpine AS frontend-build
WORKDIR /app/frontend
COPY frontend-export/package*.json ./
RUN npm ci --only=production
COPY frontend-export/ ./
RUN npm run build

# Stage 2: Build Java Backend
FROM maven:3.8-openjdk-17 AS backend-build
WORKDIR /app/backend
COPY your-java-backend/pom.xml ./
RUN mvn dependency:resolve
COPY your-java-backend/src ./src
RUN mvn clean package -DskipTests

# Stage 3: Production Image
FROM openjdk:17-jdk-slim
WORKDIR /app

# Copy Java application
COPY --from=backend-build /app/backend/target/*.jar app.jar

# Copy frontend build
COPY --from=frontend-build /app/frontend/dist /app/static

# Configure Java to serve static files
ENV SPRING_WEB_RESOURCES_STATIC_LOCATIONS=classpath:/static/

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "app.jar"]
```

#### Docker Compose

```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "8080:8080"
    environment:
      - SPRING_PROFILES_ACTIVE=production
      - DATABASE_URL=jdbc:postgresql://db:5432/yourdb
    depends_on:
      - db
    
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: yourdb
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app

volumes:
  postgres_data:
```

### Option 4: Cloud Platform Deployments

#### AWS Deployment

**Using AWS Elastic Beanstalk:**

```bash
# Install EB CLI
pip install awsebcli

# Initialize and deploy
eb init
eb create production
eb deploy
```

**Using AWS ECS:**

```yaml
# docker-compose.yml for ECS
version: '3'
services:
  app:
    image: your-registry/your-app:latest
    ports:
      - "8080:8080"
    environment:
      - SPRING_PROFILES_ACTIVE=production
```

#### Google Cloud Platform

```bash
# Deploy to Google App Engine
gcloud app deploy
```

#### Heroku Deployment

```bash
# Create Heroku app
heroku create your-app-name

# Add Java buildpack
heroku buildpacks:add heroku/java

# Deploy
git push heroku main
```

## Environment Configuration

### Frontend Environment Variables

Create `.env.production`:

```env
VITE_API_BASE_URL=https://your-backend.com/api
VITE_APP_NAME=Enterprise SaaS
VITE_ENVIRONMENT=production
VITE_ENABLE_ANALYTICS=true
```

### Java Backend Configuration

```properties
# application-production.properties
server.port=8080
spring.profiles.active=production

# Database configuration
spring.datasource.url=jdbc:postgresql://localhost:5432/yourdb
spring.datasource.username=${DB_USERNAME}
spring.datasource.password=${DB_PASSWORD}

# Security configuration
jwt.secret=${JWT_SECRET}
jwt.expiration=86400

# CORS configuration
cors.allowed-origins=https://your-domain.com
cors.allowed-methods=GET,POST,PUT,DELETE,OPTIONS
cors.allow-credentials=true

# Logging
logging.level.com.yourcompany=INFO
logging.pattern.console=%d{yyyy-MM-dd HH:mm:ss} - %msg%n
```

### Docker Environment

```env
# docker.env
DB_USERNAME=user
DB_PASSWORD=secure_password
JWT_SECRET=your_jwt_secret_key
CORS_ALLOWED_ORIGINS=https://your-domain.com
```

## Performance Optimization

### Frontend Optimization

1. **Code Splitting:**
```typescript
// Lazy load pages
const Dashboard = lazy(() => import('./pages/dashboard/Dashboard'));
const CRM = lazy(() => import('./pages/crm/CRM'));

// Use Suspense
<Suspense fallback={<LoadingSpinner />}>
  <Dashboard />
</Suspense>
```

2. **Bundle Analysis:**
```bash
npm run build -- --analyze
```

3. **Service Worker (PWA):**
```typescript
// Register service worker for caching
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js');
}
```

### Backend Optimization

1. **Database Optimization:**
```java
// Connection pooling
spring.datasource.hikari.maximum-pool-size=20
spring.datasource.hikari.minimum-idle=5
```

2. **Caching:**
```java
@EnableCaching
@Configuration
public class CacheConfig {
    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("users", "products");
    }
}
```

3. **Compression:**
```properties
server.compression.enabled=true
server.compression.mime-types=text/html,text/css,application/javascript,application/json
```

## Monitoring and Logging

### Application Monitoring

1. **Health Checks:**
```java
@RestController
public class HealthController {
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> status = new HashMap<>();
        status.put("status", "UP");
        status.put("timestamp", Instant.now().toString());
        return ResponseEntity.ok(status);
    }
}
```

2. **Metrics (Micrometer):**
```java
@Component
public class CustomMetrics {
    private final Counter loginCounter;
    
    public CustomMetrics(MeterRegistry meterRegistry) {
        this.loginCounter = meterRegistry.counter("user.login.count");
    }
    
    public void incrementLoginCount() {
        loginCounter.increment();
    }
}
```

### Logging Configuration

```xml
<!-- logback-spring.xml -->
<configuration>
    <appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>logs/application.log</file>
        <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <fileNamePattern>logs/application.%d{yyyy-MM-dd}.log</fileNamePattern>
            <maxHistory>30</maxHistory>
        </rollingPolicy>
        <encoder>
            <pattern>%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <root level="INFO">
        <appender-ref ref="STDOUT"/>
        <appender-ref ref="FILE"/>
    </root>
</configuration>
```

### Frontend Error Tracking

```typescript
// Error boundary component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // Log error to monitoring service
    console.error('Frontend Error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return <ErrorFallback />;
    }
    return this.props.children;
  }
}
```

## SSL/TLS Configuration

### Nginx SSL

```nginx
server {
    listen 443 ssl http2;
    server_name your-domain.com;
    
    ssl_certificate /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;
    
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload";
}
```

### Java Backend SSL

```properties
# HTTPS configuration
server.ssl.enabled=true
server.ssl.key-store=classpath:keystore.p12
server.ssl.key-store-password=password
server.ssl.keyStoreType=PKCS12
server.ssl.keyAlias=tomcat
```

## Backup and Recovery

### Database Backup

```bash
# PostgreSQL backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -h localhost -U user yourdb > backup_${DATE}.sql
```

### Application Backup

```bash
# Create deployment backup
tar -czf backup_$(date +%Y%m%d).tar.gz \
  your-java-backend/target/*.jar \
  frontend-export/dist \
  config/
```

This deployment guide provides comprehensive instructions for various deployment scenarios. Choose the option that best fits your infrastructure and requirements.