# Java Backend Integration Guide

This guide provides step-by-step instructions for integrating the React frontend with a Java backend (Spring Boot, Spring MVC, or any Java web framework).

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Frontend Configuration](#frontend-configuration)
3. [API Integration](#api-integration)
4. [Authentication Setup](#authentication-setup)
5. [CORS Configuration](#cors-configuration)
6. [Build and Deployment](#build-and-deployment)
7. [Testing Integration](#testing-integration)

## Prerequisites

### Frontend Requirements
- Node.js 18+ and npm
- The complete frontend export package
- Understanding of React and TypeScript

### Java Backend Requirements
- Java 11+ or Java 17+
- Spring Boot 2.7+ or 3.x (recommended)
- Maven or Gradle build tool
- Database (PostgreSQL, MySQL, or H2 for testing)

## Frontend Configuration

### 1. Install Dependencies

```bash
cd frontend-export
npm install
```

### 2. Configure API Base URL

Update `src/lib/config.ts`:

```typescript
// Update this to point to your Java backend
export const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://your-java-backend.com/api'
  : 'http://localhost:8080/api';

export const API_CONFIG = {
  baseURL: API_BASE_URL,
  timeout: 10000,
  withCredentials: true, // For session-based auth
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
};
```

### 3. Update Query Client Configuration

Modify `src/lib/queryClient.ts`:

```typescript
// Update the apiRequest function to work with Java backend
export async function apiRequest(
  endpoint: string,
  options: RequestInit = {}
): Promise<Response> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const config: RequestInit = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    credentials: 'include', // Important for session cookies
  };

  // Add JWT token if available
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers = {
      ...config.headers,
      'Authorization': `Bearer ${token}`,
    };
  }

  const response = await fetch(url, config);
  
  if (!response.ok) {
    if (response.status === 401) {
      // Handle unauthorized access
      localStorage.removeItem('authToken');
      window.location.href = '/login';
    }
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response;
}
```

## API Integration

### 1. Java Backend API Structure

Your Java backend should implement these REST endpoints (detailed in `API_ENDPOINTS.md`):

```
Authentication:
POST /api/auth/login
POST /api/auth/register
POST /api/auth/logout
GET  /api/auth/user

Users:
GET    /api/users
POST   /api/users
PUT    /api/users/{id}
DELETE /api/users/{id}

Leads:
GET    /api/leads
POST   /api/leads
PUT    /api/leads/{id}
DELETE /api/leads/{id}

[... other endpoints ...]
```

### 2. Java Model Classes

Create Java entities matching the frontend types:

```java
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String username;
    
    @Column(unique = true, nullable = false)
    private String email;
    
    @Column(nullable = false)
    private String password;
    
    @Enumerated(EnumType.STRING)
    private Role role;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    // Getters and setters...
}

public enum Role {
    ADMIN, MANAGER, SALES, SUPPORT
}
```

### 3. Spring Boot Controller Example

```java
@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173") // Vite dev server
public class UserController {
    
    @Autowired
    private UserService userService;
    
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.findAll();
        return ResponseEntity.ok(users);
    }
    
    @PostMapping
    public ResponseEntity<User> createUser(@Valid @RequestBody CreateUserRequest request) {
        User user = userService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(user);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @Valid @RequestBody UpdateUserRequest request) {
        User user = userService.update(id, request);
        return ResponseEntity.ok(user);
    }
}
```

## Authentication Setup

### 1. JWT-Based Authentication (Recommended)

#### Java Backend (Spring Security):

```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .cors().and()
            .csrf().disable()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and()
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/public/**").permitAll()
                .anyRequest().authenticated()
            )
            .oauth2ResourceServer().jwt();
        
        return http.build();
    }
}

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        // Authenticate user and generate JWT
        String token = authService.authenticate(request.getEmail(), request.getPassword());
        User user = userService.findByEmail(request.getEmail());
        
        return ResponseEntity.ok(new AuthResponse(token, user));
    }
}
```

#### Frontend Authentication Context:

```typescript
// src/context/AuthContext.tsx - Already implemented
// Just ensure the login method saves the JWT token:

const login = async (email: string, password: string): Promise<boolean> => {
  try {
    const response = await apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    
    const data = await response.json();
    
    if (data.token) {
      localStorage.setItem('authToken', data.token);
      setUser(data.user);
      return true;
    }
    return false;
  } catch (error) {
    console.error('Login failed:', error);
    return false;
  }
};
```

### 2. Session-Based Authentication (Alternative)

If you prefer session-based authentication, configure:

#### Java Backend:
```java
@Configuration
public class SessionConfig {
    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }
}
```

#### Frontend:
```typescript
// Ensure credentials are included in requests
const config: RequestInit = {
  ...options,
  credentials: 'include', // Important for session cookies
};
```

## CORS Configuration

### Java Backend CORS Setup

```java
@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer {
    
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins(
                    "http://localhost:5173", // Vite dev server
                    "http://localhost:3000", // Alternative dev port
                    "https://your-frontend-domain.com" // Production
                )
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
```

## Build and Deployment

### 1. Development Setup

#### Start Java Backend:
```bash
cd your-java-backend
./mvnw spring-boot:run
# or
./gradlew bootRun
```

#### Start Frontend:
```bash
cd frontend-export
npm run dev
```

### 2. Production Build

#### Build Frontend:
```bash
cd frontend-export
npm run build
```

This creates a `dist/` folder with static files.

#### Serve Frontend from Java Backend:

```java
@Configuration
public class StaticResourceConfig implements WebMvcConfigurer {
    
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/static/")
                .setCachePeriod(3600)
                .resourceChain(true);
    }
}
```

Copy the `dist/` contents to `src/main/resources/static/` in your Java project.

### 3. Docker Deployment (Optional)

```dockerfile
# Dockerfile for the complete application
FROM openjdk:17-jdk-slim

# Copy Java application
COPY target/your-app.jar app.jar

# Copy frontend build
COPY frontend-export/dist /app/static

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "/app.jar"]
```

## Testing Integration

### 1. API Testing

Test each endpoint with tools like Postman or write integration tests:

```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase
class UserControllerTest {
    
    @Autowired
    private TestRestTemplate restTemplate;
    
    @Test
    void shouldCreateUser() {
        CreateUserRequest request = new CreateUserRequest("test@example.com", "password", "Test User");
        
        ResponseEntity<User> response = restTemplate.postForEntity("/api/users", request, User.class);
        
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody().getEmail()).isEqualTo("test@example.com");
    }
}
```

### 2. Frontend Integration Testing

Use the browser's network tab to verify:
- API calls are reaching the correct endpoints
- Authentication headers are included
- CORS is properly configured
- Response data matches expected format

## Troubleshooting Common Issues

1. **CORS Errors**: Ensure CORS is properly configured on the Java backend
2. **Authentication Issues**: Verify JWT token format and expiration
3. **API Endpoint Mismatches**: Check endpoint URLs and HTTP methods
4. **Data Format Issues**: Ensure Java DTOs match TypeScript interfaces

For detailed API specifications, refer to `API_ENDPOINTS.md`.
For authentication specifics, see `AUTHENTICATION.md`.
For deployment options, check `DEPLOYMENT.md`.