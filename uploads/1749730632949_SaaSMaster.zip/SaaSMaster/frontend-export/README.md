# Frontend Export for Java Backend Integration

This directory contains the complete frontend application ready for integration with a Java backend. The frontend is built with React, TypeScript, and Tailwind CSS, maintaining the exact same UI/UX as the original application.

## Directory Structure

```
frontend-export/
├── src/                    # Source files
│   ├── components/         # Reusable UI components
│   ├── pages/             # Page components
│   ├── context/           # React contexts
│   ├── hooks/             # Custom React hooks
│   ├── lib/               # Utility libraries
│   └── assets/            # Static assets
├── public/                # Public assets
├── docs/                  # Integration documentation
├── package.json           # Dependencies
└── configuration files    # Build and config files
```

## Key Features Maintained

- ✅ Complete Enterprise SaaS UI/UX
- ✅ 12 Business Modules (CRM, EPC, CPQ, etc.)
- ✅ Role-based dashboards
- ✅ Dark/Light theme support
- ✅ Responsive design
- ✅ Professional charts and analytics
- ✅ Authentication system
- ✅ Notification system
- ✅ Configurable branding

## Integration Files

- `docs/JAVA_INTEGRATION.md` - Complete integration guide
- `docs/API_ENDPOINTS.md` - Required API endpoints for Java backend
- `docs/AUTHENTICATION.md` - Authentication flow documentation
- `docs/DEPLOYMENT.md` - Deployment instructions
- `docs/CONFIGURATION.md` - Configuration and customization guide

## Quick Start

1. Install dependencies: `npm install`
2. Configure API endpoints in `src/lib/config.ts`
3. Update authentication settings
4. Build for production: `npm run build`

Refer to the documentation in the `docs/` folder for detailed integration steps.