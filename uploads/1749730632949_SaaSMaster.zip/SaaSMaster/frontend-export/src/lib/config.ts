export interface AppConfig {
  brandName: string;
  logoPath?: string;
  primaryColor: string;
  secondaryColor: string;
  enabledModules: string[];
  darkMode: boolean;
}

// Updated configuration for Java backend integration
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 
  (import.meta.env.MODE === 'production' 
    ? 'https://your-java-backend.com/api'
    : 'http://localhost:8080/api');

export const API_CONFIG = {
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
};

export const defaultConfig: AppConfig = {
  brandName: "Enterprise SaaS",
  logoPath: "/assets/logo.png",
  primaryColor: "#3b82f6",
  secondaryColor: "#64748b",
  enabledModules: [
    "DASHBOARD",
    "CRM", 
    "EPC",
    "PRICEBOOK",
    "CPQ",
    "FINOPS",
    "SUPPORT",
    "SUBSCRIPTIONS",
    "ORDERS",
    "MARKETPLACE",
    "ONBOARDING",
    "ADMIN"
  ],
  darkMode: true
};

export const moduleConfig = {
  DASHBOARD: {
    name: "Dashboard",
    icon: "LayoutDashboard",
    path: "/dashboard",
    description: "Main analytics and overview",
    permissions: ["VIEW_DASHBOARD"]
  },
  CRM: {
    name: "CRM",
    icon: "Users",
    path: "/crm",
    description: "Customer relationship management",
    permissions: ["VIEW_CRM", "MANAGE_LEADS"]
  },
  EPC: {
    name: "EPC",
    icon: "Briefcase",
    path: "/epc",
    description: "Enterprise partner center",
    permissions: ["VIEW_EPC"]
  },
  PRICEBOOK: {
    name: "Pricebook",
    icon: "DollarSign",
    path: "/pricebook",
    description: "Product pricing management",
    permissions: ["VIEW_PRICEBOOK", "MANAGE_PRICING"]
  },
  CPQ: {
    name: "CPQ",
    icon: "Calculator",
    path: "/cpq",
    description: "Configure, price, quote",
    permissions: ["VIEW_CPQ", "CREATE_QUOTES"]
  },
  FINOPS: {
    name: "FinOps",
    icon: "TrendingUp",
    path: "/finops",
    description: "Financial operations",
    permissions: ["VIEW_FINOPS", "MANAGE_FINANCE"]
  },
  SUPPORT: {
    name: "Support",
    icon: "HelpCircle",
    path: "/support",
    description: "Customer support system",
    permissions: ["VIEW_SUPPORT", "MANAGE_TICKETS"]
  },
  SUBSCRIPTIONS: {
    name: "Subscriptions",
    icon: "RefreshCw",
    path: "/subscriptions",
    description: "Subscription management",
    permissions: ["VIEW_SUBSCRIPTIONS"]
  },
  ORDERS: {
    name: "Orders",
    icon: "ShoppingCart",
    path: "/orders",
    description: "Order management",
    permissions: ["VIEW_ORDERS"]
  },
  MARKETPLACE: {
    name: "Marketplace",
    icon: "Store",
    path: "/marketplace",
    description: "Product marketplace",
    permissions: ["VIEW_MARKETPLACE"]
  },
  ONBOARDING: {
    name: "Onboarding",
    icon: "UserPlus",
    path: "/onboarding",
    description: "User onboarding flows",
    permissions: ["VIEW_ONBOARDING"]
  },
  ADMIN: {
    name: "Admin",
    icon: "Settings",
    path: "/admin",
    description: "System administration",
    permissions: ["ADMIN_ACCESS"]
  }
};

export const rolePermissions = {
  ADMIN: [
    "VIEW_DASHBOARD", "VIEW_CRM", "MANAGE_LEADS", "VIEW_EPC", 
    "VIEW_PRICEBOOK", "MANAGE_PRICING", "VIEW_CPQ", "CREATE_QUOTES",
    "VIEW_FINOPS", "MANAGE_FINANCE", "VIEW_SUPPORT", "MANAGE_TICKETS",
    "VIEW_SUBSCRIPTIONS", "VIEW_ORDERS", "VIEW_MARKETPLACE", 
    "VIEW_ONBOARDING", "ADMIN_ACCESS"
  ],
  MANAGER: [
    "VIEW_DASHBOARD", "VIEW_CRM", "MANAGE_LEADS", "VIEW_PRICEBOOK",
    "VIEW_CPQ", "CREATE_QUOTES", "VIEW_FINOPS", "VIEW_SUPPORT",
    "MANAGE_TICKETS", "VIEW_SUBSCRIPTIONS", "VIEW_ORDERS"
  ],
  SALES: [
    "VIEW_DASHBOARD", "VIEW_CRM", "MANAGE_LEADS", "VIEW_PRICEBOOK",
    "VIEW_CPQ", "CREATE_QUOTES", "VIEW_SUPPORT"
  ],
  SUPPORT: [
    "VIEW_DASHBOARD", "VIEW_CRM", "VIEW_SUPPORT", "MANAGE_TICKETS",
    "VIEW_SUBSCRIPTIONS", "VIEW_ORDERS"
  ]
};

export const userShortcuts = {
  ADMIN: ["DASHBOARD", "CRM", "ADMIN"],
  MANAGER: ["DASHBOARD", "CRM", "FINOPS"],
  SALES: ["DASHBOARD", "CRM", "CPQ"],
  SUPPORT: ["DASHBOARD", "SUPPORT", "CRM"]
};