import { QueryClient } from "@tanstack/react-query";
import { API_CONFIG } from "./config";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    if (res.status === 401) {
      // Handle unauthorized access
      localStorage.removeItem('authToken');
      window.location.href = '/login';
    }
    const error = await res.text();
    throw new Error(error);
  }
}

export async function apiRequest(
  endpoint: string,
  options: RequestInit = {}
): Promise<Response> {
  const url = `${API_CONFIG.baseURL}${endpoint}`;
  
  const config: RequestInit = {
    ...options,
    headers: {
      ...API_CONFIG.headers,
      ...options.headers,
    },
    credentials: 'include', // Important for session cookies
  };

  // Add JWT token if available
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers = {
      ...config.headers,
      'Authorization': `Bearer ${token}`,
    };
  }

  const res = await fetch(url, config);
  throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => (context: { queryKey: readonly string[] }) => Promise<T | null> =
  ({ on401 = "throw" }) =>
  async ({ queryKey }) => {
    const endpoint = Array.isArray(queryKey) ? queryKey.join("/") : String(queryKey);
    try {
      const res = await apiRequest(endpoint);
      return res.json();
    } catch (error) {
      // Handle unauthorized differently based on configuration
      if (error instanceof Error && error.message.includes("401")) {
        if (on401 === "returnNull") {
          return null;
        }
      }
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: (failureCount, error) => {
        if (error instanceof Error && error.message.includes("401")) {
          return false; // Don't retry on authentication errors
        }
        return failureCount < 3;
      },
    },
  },
});