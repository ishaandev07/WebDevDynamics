module.exports = {
  apps: [{
    name: 'stayfitfine',
    script: 'server/index.ts',
    cwd: '/var/www/stayfitfine',
    instances: 'max',
    exec_mode: 'cluster',
    interpreter: 'node',
    interpreter_args: '--loader tsx',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: '/var/log/stayfitfine/error.log',
    out_file: '/var/log/stayfitfine/out.log',
    log_file: '/var/log/stayfitfine/combined.log',
    time: true,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024'
  }]
};